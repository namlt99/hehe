export const ENV_CONFIG = {
    app: {
        port: 1999,
        hostname: '192.168.1.2',
    },
};

export const CORS_CONFIG = {
    origin: true,
    methods: "POST,GET,DELETE,PUT,PATCH,OPTIONS,HEAD",
    credentials: true, // allow cookies and other credential to be include request
};

export const CRONJOB_CONFIG = {
    REPEAT_TIME: "0 5 * * *", // every 5AM
    TIME_ZONE: "Asia/Ho_Chi_Minh", // time zone in Ho Chi Minh
};


export const FILE_CONFIG = {
    publish_path: "src/files",
    publish_type: /pdf|doc|docx/,
    max_size: 10 * 1024 * 1024, // limit 10mb
};

// ACCESS TOKEN
export const ACCESS_TOKEN_CONFIG = {
    token: '696e73706563746f726d616e6167656d656e745f6163636573735f746f6b656e',
    expiredTime: '12h',
};


export const REFRESH_TOKEN_CONFIG = {
    token: "refresh_token", // signature
    expiredTime: "10h",
};