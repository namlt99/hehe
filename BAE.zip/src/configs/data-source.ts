import { DataSource } from "typeorm";
import { Attachment } from "../entities/Attachment";
import { CertificateStatus } from "../entities/CertificateStatus";
import { InspectorInformation } from "../entities/InspectorInformation";
import { History } from "../entities/History";
import { User } from "../entities/User";
import { ProcessDetail } from "../entities/ProcessDetail";
import { Process } from "../entities/Process";
import { Plant } from "../entities/Plant";
import "reflect-metadata";
import { seedCertificateStatus, seedPlants, seedProcess, seedProcessDetail } from "../seeders/data-seeder";

export const AppDataSource = new DataSource({
    type: "mysql",
    host: "localhost",
    port: 3306,
    username: "root",
    password: "123456",
    database: "inspectormanagement",
    // synchronize: true, // auto tao table
    entities: [
        CertificateStatus,
        Attachment,
        History,
        InspectorInformation,
        Plant,
        Process,
        ProcessDetail,
        User,
    ],
});


AppDataSource.initialize()
    .then(async () => {
        // await seedPlants();
        // await seedProcess();
        // await seedProcessDetail();
        // await seedCertificateStatus();
        console.log("Data Source has been initialized!")

    })
    .catch((err) => {
        console.error("Error during Data Source initialization", err)
    })

export const AppIntraDataSource = new DataSource({
    type: "mysql",
    host: "107.118.212.71",
    port: 3306,
    username: "rnd_sw",
    password: "R72OU6XxtjIZ8mik",
    database: "intradb",
    synchronize: false, 
    entities: [
        // CertificateStatus,
        // Attachment,
        // History,
        // InspectorInformation,
        // Plant,
        // Process,
        // ProcessDetail,
        // User,
    ],
});

// AppIntraDataSource.initialize()
// .then(async () => {
  
//     console.log("Intra Data Source has been initialized!")

// })
// .catch((err) => {
//     console.error("Error during Data Source initialization", err)
// })