export const EMAIL_PAYLOAD_CONST = {
  SENDER: 'qweb.sec@samsung.com',
  SUBJECT :'[Q-Web] Inspector certification expiration notification'
}