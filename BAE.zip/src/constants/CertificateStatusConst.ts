/* Inspetor Status:
1 - Certification Plan: Khi chứng nhận còn hạn -30 ngày đổ lại.
2 - Certification Complete: Khi đã đăng ký chứng nhận lên.
3 - Certification No Need: Khi add new 1 người mới. 
4 - Certification Delay: Quá hạn chứng nhận.
*/
// export const CERTIFICATE_STATUS = {
//   NO_NEED: 3, //Certification No Need
//   COMPLETE: "Certification Complete",
//   PLAN: "Certification Plan",
//   DELAY: "Certification Delay",
// }

export enum CERTIFICATE_STATUS {
  PLAN = 1,
  COMPLETE,
  NO_NEED,
  DELAY
}