export const DATA_TABLE_NAME = {
    INSPECTOR_INFORMATION: "inspectorinformation",
    PLANT: "plant",
    PROCESS: "process",
    PROCESS_DETAIL: "processDetail",
    CERTIFICATE_STATUS: "certificateStatus",
    ATTACHMENT: "attachment",
    USER: "user",
    HISTORY: "history"
};


export const INTRA_DATA_TABLE_NAME = {
    ESB_EMAILS: "esb_emails",
    STAFFS_NEW: "staffs_new",
};