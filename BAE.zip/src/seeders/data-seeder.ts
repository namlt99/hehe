import { Process } from "../entities/Process";
import { AppDataSource } from "../configs/data-source";
import { Plant } from "../entities/Plant";
import { CertificateStatus } from "../entities/CertificateStatus";
import { ProcessDetail } from "../entities/ProcessDetail";

export async function seedPlants(): Promise<void> {
    const userRepository =  AppDataSource.getRepository(Plant);
  
    // Kiểm tra xem bảng User có dữ liệu không
    const usersCount = await userRepository.count();
    if (usersCount === 0) {
      // Thêm dữ liệu mẫu cho bảng User
      await userRepository.save([
        { name: 'ABC' },
        { name: 'DEF'},
      ]);
      console.log('Sample users seeded successfully');
    } else {
      console.log('User table already seeded');
    }
  }

  export async function seedProcess(): Promise<void> {
    const userRepository =  AppDataSource.getRepository(Process);
  
    // Kiểm tra xem bảng User có dữ liệu không
    const usersCount = await userRepository.count();
    if (usersCount === 0) {
      // Thêm dữ liệu mẫu cho bảng User
      await userRepository.save([
        { name: 'CS' },
        { name: 'Manufacturing'},
      ]);
      console.log('Sample users seeded successfully');
    } else {
      console.log('User table already seeded');
    }
  }

  export async function seedProcessDetail(): Promise<void> {
    const userRepository =  AppDataSource.getRepository(ProcessDetail);
  
    // Kiểm tra xem bảng User có dữ liệu không
    const usersCount = await userRepository.count();
    if (usersCount === 0) {
      // Thêm dữ liệu mẫu cho bảng User
      await userRepository.save([
        { name: '1' },
        { name: '2'},
        { name: '3'},
        { name: '4'},
        { name: '5'},
        { name: '6'},
      ]);
      console.log('Sample users seeded successfully');
    } else {
      console.log('User table already seeded');
    }
  }

  export async function seedCertificateStatus(): Promise<void> {
    const userRepository =  AppDataSource.getRepository(CertificateStatus);
  
    // Kiểm tra xem bảng User có dữ liệu không
    const usersCount = await userRepository.count();
    if (usersCount === 0) {
      // Thêm dữ liệu mẫu cho bảng User
      await userRepository.save([
        { name: 'Certification Plan' },
        { name: 'Certification Complete'},
        { name: 'Certification No Need'},
        { name: 'Certification Delay'},
      ]);
      console.log('Sample users seeded successfully');
    } else {
      console.log('User table already seeded');
    }
  }