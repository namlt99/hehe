import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: 'staffs_new' })
export class IntraStaff {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    user: string;

    @Column()
    eid: string;

    @Column()
    fullname: string;

    @Column()
    fullname_en: string;

    @Column()
    email: string;

    @Column()
    gender: string;

    @Column()
    phone: string;

    @Column()
    team: string;

    @Column()
    group: string;

    @Column()
    department: string;
    
    @Column()
    division: string;

    @Column()
    sen_date: string;

    @Column()
    cost_center: string;

    @Column()
    cost_center_title: string;

    @Column()
    status: boolean;

    @Column()
    current: string;
}
