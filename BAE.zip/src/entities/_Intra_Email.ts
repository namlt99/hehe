import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: 'esb_emails' })
export class IntraEmail {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    sender: string;

    @Column()
    subject: string;

    @Column()
    receivers: number;

    @Column()
    body: string;

    @Column()
    created: boolean;

}
