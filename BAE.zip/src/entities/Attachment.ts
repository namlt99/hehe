import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { InspectorInformation } from "./InspectorInformation";

@Entity({ name: 'attachment' })
export class Attachment {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("varchar", { length: 200, nullable: true },)
    file_name: string;

    @Column("varchar", { length: 200, nullable: true })
    mime_type: string;

    @Column('int', { nullable: true })
    file_size: number;

    @Column("varchar", { length: 200, nullable: true })
    file_name_unique: string;

    @Column({ default: true })
    is_active: boolean;

    @Column("varchar", { length: 200, nullable: true })
    created_by: string;

    @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
    created_at: string;

    @Column("varchar", { length: 200, nullable: true })
    modified_by: string;

    @Column({ type: 'timestamp', nullable: true })
    modified_at: string;

    @ManyToOne(() => InspectorInformation, inspector => inspector.id)
    inspector: InspectorInformation;
}
