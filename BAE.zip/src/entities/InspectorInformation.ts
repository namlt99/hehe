import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { CertificateStatus } from "./CertificateStatus";
import { Plant } from "./Plant";
import { Process } from "./Process";
import { ProcessDetail } from "./ProcessDetail";

@Entity({ name: "inspectorInformation" })
export class InspectorInformation {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("varchar", { length: 200 })
    employee_no: string;

    @Column("varchar", { length: 200 })
    knox_id: string;

    @Column("varchar", { length: 200 })
    employee_name: string;

    @Column("varchar", { length: 200 })
    employee_team: string;

    @Column("varchar", { length: 200 })
    gbm: string;

    @Column("varchar", { length: 200, nullable: true })
    product: string;

    @Column("varchar", { length: 200, nullable: true })
    part: string;

    @Column({ type: 'timestamp' })
    enter_date: string;

    @Column('decimal', { nullable: true })
    pass_score: number;

    @Column({ type: 'timestamp', nullable: true })
    start_date: string;

    @Column({ type: 'timestamp', nullable: true })
    end_date: string;

    @Column({ type: 'timestamp', nullable: true })
    last_certificate_date: string;

    @Column({ type: 'timestamp', nullable: true })
    next_certificate_date: string;

    @Column("int",{nullable: true})
    delay: number;

    @Column("varchar", { length: 256, nullable: true })
    remark: string;

    @Column({ default: true })
    is_active: boolean;

    @Column("varchar", { length: 200, nullable: true })
    registrant_no: string;

    @Column("varchar", { length: 200, nullable: true })
    registrant_knox_id: string;

    @Column("varchar", { length: 200, nullable: true })
    registrant_name: string;

    @Column({ type: 'timestamp', nullable: true })
    register_date: string;

    @Column("varchar", { length: 200 })
    created_by: string;

    @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
    created_at: string;

    @Column("varchar", { length: 200, nullable: true })
    modified_by: string;

    @Column({ type: 'timestamp', nullable: true })
    modified_at: string;

    @ManyToOne(() => Plant, plant => plant.id)
    plant: Plant;

    @ManyToOne(() => Process, process => process.id)
    process: Process;

    @ManyToOne(() => ProcessDetail, process_detail => process_detail.id)
    process_detail: ProcessDetail;

    @ManyToOne(() => CertificateStatus, certificate_status => certificate_status.id)
    certificate_status: CertificateStatus;
}
