import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: "user" })
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("varchar", { length: 200 })
    employee_no: string;

    @Column("varchar", { length: 200 })
    knox_id: string;

    @Column("varchar", { length: 200 })
    employee_name: string;

    @Column("varchar", { length: 200 })
    employee_email: string;

    @Column({ default: false })
    is_admin: boolean;

    @Column("varchar", { length: 200, nullable: true })
    current: string;

    @Column({ nullable: true })
    status: boolean;

    @Column({ default: true })
    is_active: boolean;

    @Column("varchar", { length: 200, nullable: true })
    set_role_by: string;

    @Column({ type: 'timestamp', nullable: true })
    set_role_at: string;

    @Column("varchar", { length: 200, nullable: true })
    created_by: string;

    @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP'})
    created_at: string;

    @Column("varchar", { length: 200, nullable: true })
    modified_by: string;

    @Column({ type: 'timestamp', nullable: true })
    modified_at: string;
}
