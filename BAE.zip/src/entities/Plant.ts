import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({name: "plant"})
export class Plant {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column("varchar", { length: 200 ,nullable:true})
    name: string;

    @Column({default:true})
    is_active: boolean; 
    
    @Column("varchar", { length: 200,nullable:true })
    created_by: string; 
    
    @Column({ type: 'timestamp',default: () => 'CURRENT_TIMESTAMP' })
    created_at: string; 
    
    @Column("varchar", { length: 200,nullable:true })
    modified_by: string; 
    
    @Column({ type: 'timestamp',nullable:true })
    modified_at: string;
}
