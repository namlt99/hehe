import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: "history" })
export class History {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("varchar", { length: 200 ,nullable:true})
    action: string;

    @Column("varchar", { length: 200 ,nullable:true})
    table_name: string;

    @Column({ type: 'json',nullable:true })
    old_data: any;

    @Column({ type: 'json' ,nullable:true})
    new_data: any;

    @Column({ type: 'timestamp',default: () => 'CURRENT_TIMESTAMP' })
    timestamp: string;
}
