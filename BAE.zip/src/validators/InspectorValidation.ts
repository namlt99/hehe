import { check } from "express-validator";

export class InspectorValidation {

    public static AddNewInspectorValidator() {
        return [
        check('employee_no','employee_no does not empty').not().isEmpty(),
        check('knox_id','knox_id does not empty').not().isEmpty(),
        check('plant_id','plant_id does not empty').not().isEmpty().isInt({min: 1, max:3}).withMessage('min 1 max 3'),
        check('process_id','process_id does not empty').not().isEmpty().isInt({min: 1, max:3}).withMessage('min 1 max 3'),
        check('process_detail_id','process_detail_id does not empty').not().isEmpty().isInt({min: 1, max:8}).withMessage('min 1 max 8'),
        check('certificate_status_id','certificate_status_id does not empty').not().isEmpty().isInt({min: 1, max:4}).withMessage('min 1 max 4'),
        check('created_by','created_by does not empty').not().isEmpty()
      ];
    }

    public static getByIdValidator(){
      return [
        check('id','id does not empty').not().isEmpty(),
      ];
    }

    public static RegisterCertValidator() {
      return [
      check('id','id does not empty').not().isEmpty(),
      check('pass_score','pass_score does not empty and min 0 max 100').not().isEmpty().isInt({min: 0, max: 100}),
      check('start_date','start_date does not empty').not().isEmpty().withMessage("incorrect date format"),
      check('end_date','end_date does not empty').not().isEmpty().withMessage("incorrect date format"),
      check('last_certificate_date','last_certificate_date does not empty').not().isEmpty().withMessage("incorrect date format"),
      check('next_certificate_date','next_certificate_date does not empty').not().isEmpty().withMessage("incorrect date format"),
      check('registrant_no','registrant_no does not empty').not().isEmpty(),
      check('registrant_knox_id','registrant_knox_id does not empty').not().isEmpty(),
      check('registrant_name','registrant_name does not empty').not().isEmpty(),
      ];
    }

    public static UpdateCertValidator() {
      return [
      check('id','id does not empty').not().isEmpty(),
      check('pass_score','pass_score does not empty and min 0 max 100').not().isEmpty().isInt({min: 0, max: 100}),
      check('start_date','start_date does not empty').not().isEmpty().withMessage("incorrect date format"),
      check('end_date','end_date does not empty').not().isEmpty().withMessage("incorrect date format"),
      check('last_certificate_date','last_certificate_date does not empty').not().isEmpty().withMessage("incorrect date format"),
      check('next_certificate_date','next_certificate_date does not empty').not().isEmpty().withMessage("incorrect date format"),
      check('modified_by','modified_by does not empty').not().isEmpty(),
      ];
    }

    public static InActiveMultiRowsValidator() {
      return [
      check('ids','ids array can not empty').isArray().withMessage("is not array").not().isEmpty(),
      check('deleted_by','deleted_by does not empty').not().isEmpty() 
      ];
    }

    public static ActiveMultiRowsValidator() {
      return [
      check('ids','ids array can not empty').isArray().withMessage("is not array").not().isEmpty(),
      check('actived_by','actived_by does not empty').not().isEmpty() 
      ];
    }
    public static PagingValidator() {
      return [
      check('pageNumber','pageNumber does not empty').not().isEmpty().isInt({min: 1}).withMessage('Can not get data with page number is 0'),
      check('pageSize','pageSize does not empty').not().isEmpty()
      ];
    }

}
