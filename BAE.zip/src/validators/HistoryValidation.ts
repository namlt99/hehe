import { check } from "express-validator";

export class HistoryValidation {
    public static GetHistoryValidator() {
        return [
            check("pageNumber", "pageNumber does not empty").not().isEmpty(),
            check("pageSize", "pageSize does not empty").not().isEmpty(),
        ];
    }

    public static GetHistoryByIdValidator() {
        return [check("id", "id does not empty").not().isEmpty()];
    }
}
