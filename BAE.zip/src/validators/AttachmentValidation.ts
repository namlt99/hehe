import { check } from "express-validator";

export class AttachmentValidation {
  public static DownloadAttachmentValidator() {
    return [
    check('id','id does not empty').not().isEmpty(),
    check('fileNameUnique','fileNameUnique does not empty').not().isEmpty(),
    ];
  }

  public static ExportExcelValidator() {
    return [
    check('from','from does not empty').not().isEmpty(),
    check('to','to does not empty').not().isEmpty(),
    ];
  }
}