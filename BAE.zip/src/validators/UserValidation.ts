import { check } from "express-validator";

export class UserValidation {
    public static SearchIntraUserValidator() {
        return [
            check("pageNumber", "pageNumber does not empty").not().isEmpty(),
            check("pageSize", "pageSize does not empty").not().isEmpty(),
            check("searchStr", "searchStr does not empty").not().isEmpty(),
        ];
    }

    public static SearchUserValidator() {
        return [
            check("pageNumber", "pageNumber does not empty").not().isEmpty(),
            check("pageSize", "pageSize does not empty").not().isEmpty(),
        ];
    }

    public static ChangeStatusValidator() {
        return [
            check("ids", "ids array can not empty")
                .isArray()
                .withMessage("is not array")
                .not()
                .isEmpty(),
            check("knox_ids", "knox_ids array can not empty")
                .isArray()
                .withMessage("is not array")
                .not()
                .isEmpty(),
            check("modified_by", "modified_by does not empty").not().isEmpty(),
        ];
    }
}
