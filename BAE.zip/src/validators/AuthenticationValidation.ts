import { check } from "express-validator";

export class AuthenticationValidation{
  public static AuthenticationValidator() {
    return [
    // check('pageNumber','pageNumber does not empty').not().isEmpty(),
    // check('pageSize','pageSize does not empty').not().isEmpty()
    ];
  }
}