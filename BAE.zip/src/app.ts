import express from "express";
import * as http from "http";
import cors from "cors";
import bodyParser from "body-parser";
import { CORS_CONFIG, ENV_CONFIG } from "./configs/config";
import { UserRouter } from "./routers/UserRouter";
import { InspectorRouter } from "./routers/InspectorRouter";
import { AttachmentRouter } from "./routers/AttachmentRouter";
import { HistoryRouter } from "./routers/HistoryRouter";
// import { InspectorRouter } from "./routers/InspectorRouter";
// import { AttachmentRouter } from "./routers/AttachmentRouter";
// import { AuthenticationRouter } from "./routers/AuthenticationRouter";
// import { CronjobDailyTask } from "./helpers/CronjobDailyTask";
// import { UserRouter } from "./routers/UserRouter";
// import { HistoryRouter } from "./routers/HistoryRouter";

export class AppServer {
    private app = express();
    private server: http.Server;

    // cronjobdaily = new CronjobDailyTask();

    constructor() {
        this.app = express();

        this.configMiddleWare(); // step 1
        this.createServer(); // step 2
        // this.connection.connect();
        this.getAllRouter(); // step 3
        // run cronjob
        // this.cronjobdaily.startCronJob();
        
        this.listen(); // step last
    }

    // Handling the  across the entire application
    private getAllRouter() {
        new InspectorRouter(this.app);
        new AttachmentRouter(this.app);
        // new AuthenticationRouter(this.app);
        new UserRouter(this.app);
        new HistoryRouter(this.app);
    }

    private configMiddleWare(): void {
        this.app.use(cors(CORS_CONFIG)); // setup CORS
        this.app.use(express.urlencoded({ extended: false }));
        this.app.use(bodyParser.json());
        this.app.use(express.json());
    }

    private createServer(): void {
        this.server = http.createServer(this.app);
    }

    private listen(): void {
        this.server.listen(ENV_CONFIG.app.port, () => {
            console.log(
                "Server",
                "Application running on",
                `${ENV_CONFIG.app.hostname}:${ENV_CONFIG.app.port}`
            );
        });
    }

    public getApp(): express.Application {
        return this.app;
    }
}
