export function formatDelay(delay: string): string {
    const abc = Number.parseInt(delay);
    if (!Number.isNaN(abc)) {
        return delay.toString();
    }
    return "";
}
