import jwt from "jsonwebtoken";
import jwtSimple from "jwt-simple"; 
import { ACCESS_TOKEN_CONFIG, REFRESH_TOKEN_CONFIG } from "../configs/config";
import { addHours, addMinutes, format } from "date-fns";

export class JWTTokenService {
    /**
     * generate Access Token
     */
    public static generateAccessToken(response: any): Promise<string> {
        // console.log("ACCESS_TOKEN_CONFIG.token", ACCESS_TOKEN_CONFIG.token);
        return new Promise<string>((resolve, reject) => {
            jwt.sign(
                response,
                ACCESS_TOKEN_CONFIG.token, // access token
                { expiresIn: ACCESS_TOKEN_CONFIG.expiredTime }, // access expired time
                (err, token) => {
                    if (err) reject(err);
                    resolve(token);
                }
            );
        });
    }

    /**
     * generate Refresh Token
     */
    public static generateRefreshToken(response: any): Promise<string> {
        return new Promise<string>((resolve, reject) => {
            jwt.sign(
                response,
                REFRESH_TOKEN_CONFIG.token, // refresh token
                { expiresIn: REFRESH_TOKEN_CONFIG.expiredTime }, // refresh expired time
                (err, token) => {
                    if (err) reject(err);
                    resolve(token);
                }
            );
        });
    }

    /**
     * verify Token
     */
    public static verifyToken(
        inputToken: string,
        callback?: (err: any, data: any) => void
    ): Promise<any> {
        let tokenDefault = ACCESS_TOKEN_CONFIG.token;
        return new Promise<string>((resolve, reject) => {
            // console.log("token dedault", tokenDefault);
            // console.log("inputToken", inputToken);
            jwt.verify(inputToken, tokenDefault, (err, decode) => {
                callback(err, decode);
                if (err) reject(err);
                resolve(decode);
            });
        });
    }

    public static genToken(response:any):string{
        const expireTime = addHours(new Date(),12);
        const payload = {
            user: response,
            exp: format(expireTime,'yyyy-MM-dd HH:mm:ss')
        }
        return jwtSimple.encode(payload, ACCESS_TOKEN_CONFIG.token);
    }

}
