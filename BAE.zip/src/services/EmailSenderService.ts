import { EmailPayloadModel } from "../models/EmailModel";
import { InspectorController } from "../controllers/InspectorController";
import { EMAIL_PAYLOAD_CONST } from "../constants/EmailpayloadConst";
import { footer, header } from "src/html_templates/emailTemplate";
import { ddMMyyyy_Short_Format } from "src/helper/dateHandler";
import { AppIntraDataSource } from "src/configs/data-source";
import { IntraEmail } from "src/entities/_Intra_Email";

export class EmailSenderService {
    private static intraEmailRepository = AppIntraDataSource.getRepository(IntraEmail);

    constructor() { }

    public static async sendEmail() {
        try {
            const payload = await EmailSenderService.buildEmailPayload();
            if (payload) {
                await EmailSenderService.intraEmailRepository
                    .createQueryBuilder()
                    .insert()
                    .into(IntraEmail)
                    .values(payload as any)
                    .execute()

                console.log("send email success");
            }
        } catch (error) {
            console.log("error", error);
        }
    }

    public static async buildEmailPayload() {
        const listOverdue =
            await InspectorController.getListOfOverdueCertificates();

        let emailPayload: EmailPayloadModel = {
            sender: EMAIL_PAYLOAD_CONST.SENDER,
            subject: EMAIL_PAYLOAD_CONST.SUBJECT,
            receivers: "",
            body: header,
            created: new Date(),
        };

        if (listOverdue && listOverdue.length > 0) {
            const inspectorList = listOverdue.map((e) => {
                return EmailSenderService.formatDataToSendEmail(e);
            });
            for (let e of inspectorList) {
                emailPayload.receivers += `"${e.knox_id}@samsung.com",`;
                if (e.created_by) {
                    emailPayload.receivers += `"${e.created_by}@samsung.com",`;
                }
                if (e.registrant_knox_id) {
                    emailPayload.receivers += `"${e.registrant_knox_id}@samsung.com",`;
                }

                emailPayload.body += `
                  <tr>
                  <td style="text-align: center; border: 0px solid grey;" class="cui-real-td"><p>${e.no
                    }</p>
                  </td><td style="text-align: center; border: 0px solid grey;" class="cui-real-td"><p>${e.employee_no
                    }</p>
                  </td><td class="cui-real-td" style="border: 0px solid grey;"><p>${e.name
                    }</p>
                  </td><td class="cui-real-td" style="border: 0px solid grey;"><p>${e.team
                    }</p>
                  </td><td class="cui-real-td" style="text-align:center; border: 0px solid grey;"><p>${e.gbm
                    }</p>
                  </td><td class="cui-real-td" style="border: 0px solid grey;"><p>${e.plant
                    }</p>
                  </td><td class="cui-real-td" style="border: 0px solid grey;"><p>${e.product
                    }</p>
                  </td><td class="cui-real-td" style="border: 0px solid grey;"><p>${e.process
                    }</p>
                  </td><td class="cui-real-td" style="border: 0px solid grey;"><p>${e.detail_process
                    }</p>
                  </td><td style="text-align: center; border: 0px solid grey;" class="cui-real-td"><p>${e.last_certificate
                    }</p>
                  </td><td style="text-align: center; border: 0px solid grey;" class="cui-real-td"><p>${e.next_certificate
                    }</p>
                  </td><td style="text-align: center; border: 0px solid grey;" class="cui-real-td"><p>${e.status
                    }</p>
                  </td><td style="background-color: orange; text-align: center; border: 0px solid grey;" class="cui-real-td"><p><span style="color: white;">${e.delay !== "0" ? "-" + e.delay : e.delay
                    }</span></p></td>
                  </tr>
                  `;
            }
            emailPayload.body += footer;

            emailPayload.receivers = emailPayload.receivers.slice(0, -1);
            emailPayload.receivers = `[${Array.from(
                new Set(emailPayload.receivers.split(","))
            ).join(",")}]`;
            return emailPayload;
        } else {
            return null;
        }
    }

    private static formatDataToSendEmail(e: any) {
        return {
            no: e.no,
            employee_no: e.employee_no ? e.employee_no : "",
            knox_id: e.knox_id ? e.knox_id : "",
            name: e.employee_name ? e.employee_name : "",
            team: e.employee_team ? e.employee_team : "",
            part: e.part ? e.part : "",
            gbm: e.gbm ? e.gbm : "",
            product: e.product ? e.product : "",
            enter_date: ddMMyyyy_Short_Format(e.enter_date),
            remark: e.remark ? e.remark : "",
            last_certificate: e.last_certificate_date
                ? ddMMyyyy_Short_Format(e.last_certificate_date)
                : "",
            pass_score: e.pass_score ? e.pass_score : "",
            next_certificate: e.next_certificate_date
                ? ddMMyyyy_Short_Format(e.next_certificate_date)
                : "",
            delay: InspectorController.formatDelay(e.delay),
            created_by: e.created_by ? e.created_by : "",
            registrant_knox_id: e.registrant_knox_id
                ? e.registrant_knox_id
                : "",
            plant: e.plant_name ? e.plant_name : "",
            process: e.process_name ? e.process_name : "",
            detail_process: e.process_detail_name ? e.process_detail_name : "",
            status: e.certificate_status_name ? e.certificate_status_name : "",
        };
    }
}
