import cron from "node-cron";
import { InspectorController } from "../controllers/InspectorController";
import { EmailSenderService } from "./EmailSenderService";
import { CRONJOB_CONFIG } from "../configs/config";

export class CronjobDailyTask {
    constructor() {}

    startCronJob() {
        cron.schedule(
            CRONJOB_CONFIG.REPEAT_TIME,
            async () => {
                console.log("Running cron job");
                try {
                    await InspectorController.setStatusIsPlanWhenLessThen30Days();
                    await InspectorController.setStatusIsDelayWhenCertOutOfDate();
                    await EmailSenderService.sendEmail();
                    console.log(new Date());
                } catch (err) {
                    console.log("error", err);
                }
            },
            {
                timezone: CRONJOB_CONFIG.TIME_ZONE,
            }
        );
    }
}
