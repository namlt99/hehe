import { AppServer } from "./app";

const app = new AppServer().getApp();
// console.log(`Run on enviroment: ${process.env.NODE_ENV}`);
console.log(`Start Server....${app}`)