import { AppDataSource, AppIntraDataSource } from "../configs/data-source";
import { User } from "../entities/User";
import { IntraStaff } from "../entities/_Intra_Staff";
import { validationResult } from "express-validator";
import { InActivePayloadModel, SetAdminRolePayloadModel, UserSearchModel } from "../models/UserModel";
import { yyyyMMdd_Long_Format } from "../helper/dateHandler";

export class UserController {
    private static userRepository = AppDataSource.getRepository(User);
    private static intraUserRepository = AppIntraDataSource.getRepository(IntraStaff);

    constructor() { }

    // public static async getAllUser(req:any,res:any){
    //     // console.log(req)
    //     const users = await  UserController.repository.findOneByOrFail(3 as any);
    //     // console.log(users)
    //     return res.status(200).json({message:"success",users});
    // }

    //Begin ----------------- Intra DB
    // TODO
    public static async SearchIntraUser(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }

            const query = req.body;
            const offset = (query.pageNumber - 1) * query.pageSize;
            const limit = query.pageSize;

            // const totalCount = await intraDB(INTRA_DATA_TABLE_NAME.STAFFS_NEW)
            //     .count("* as total")
            //     .andWhere("status", 1)
            //     .first();
            const totalCount = await UserController.intraUserRepository
                .createQueryBuilder('staffs_new')
                .select("COUNT(staffs_new.*)", "total")
                .where("status = :status", { status: 1 })
                .getCount();

            // const totalFound = await intraDB(INTRA_DATA_TABLE_NAME.STAFFS_NEW)
            //     .count("* as total")
            //     .where((qb) => {
            //         qb.where("status", 1);
            //         if (query.searchStr) {
            //             const searchStr = `%${query.searchStr
            //                 .trim()
            //                 .toLowerCase()}%`;
            //             qb.andWhere(function () {
            //                 this.where("user", "like", searchStr)
            //                     .orWhere("eid", "like", searchStr)
            //                     .orWhere("fullname", "like", searchStr);
            //             });
            //         }
            //     })
            //     .first();
            const totalFound = await UserController.intraUserRepository
                .createQueryBuilder('staffs_new')
                .select("COUNT(staffs_new.*)", "total")
                .where("status = :status", { status: 1 })
                .andWhere(query.searchStr ? qb => {
                    const searchStr = `%${query.searchStr.trim().toLowerCase()}%`;
                    qb.where("staffs_new.eid LIKE :searchStr", { searchStr })
                        .orWhere("staffs_new.user LIKE :searchStr", { searchStr })
                        .orWhere("staffs_new.fullname LIKE :searchStr", { searchStr });
                } : "1=1")
                .getCount();

            let result = await await UserController.intraUserRepository
                .createQueryBuilder('staffs_new')
                .select("COUNT(staffs_new.*)", "total")
                .where("status = :status", { status: 1 })
                .andWhere(query.searchStr ? qb => {
                    const searchStr = `%${query.searchStr.trim().toLowerCase()}%`;
                    qb.where("staffs_new.eid LIKE :searchStr", { searchStr })
                        .orWhere("staffs_new.user LIKE :searchStr", { searchStr })
                        .orWhere("staffs_new.fullname LIKE :searchStr", { searchStr });
                } : "1=1")
                .offset(offset)
                .limit(limit)
                .orderBy("user", "ASC")
                .getRawMany();

            result = result.map((e) => {
                return UserController.formatIntraUserData(e, true);
            });
            return res.status(200).json({
                message: "success",
                response: {
                    total: totalCount,
                    totalFound: totalFound,
                    pageNumber: req.body.pageNumber,
                    pageSize: limit,
                    data: result,
                },
            });
        } catch (error) { }
    }

    public static async getIntraUserInfo(knox_id: string, employee_no: string) {
        try {
            let result = await UserController.intraUserRepository
                .createQueryBuilder('staffs_new')
                .select("staffs_new.*")
                .where("user = :user", { user: knox_id })
                .andWhere("eid = :eid", { eid: employee_no })
                .andWhere("status = :status", { status: 1 })
                .getRawOne();

            if (!result) {
                return null;
            }
            result = UserController.formatIntraUserData(result);
            return result;
        } catch (error) {
            return null;
        }
    }

    private static formatIntraUserData(origin: any, isShow = false) {
        const result: UserSearchModel = {
            knox_id: origin.user,
            employee_no: origin.eid,
            employee_name: origin.fullname,
            employee_name_en: origin.fullname_en,
            employee_email: origin.email,
            gender: origin.gender,
            phone: origin.phone,
            team: origin.team ? origin.team : null,
            group: origin.group ? origin.group : null,
            part: origin.department ? origin.department : null,
            gbm: origin.division,
            enter_date: isShow
                ? UserController.formatEnterDate_YYYYMMDD(origin.sen_date)
                : UserController.formatEnterDate_DDMMYYYY(origin.sen_date),
            product: origin.department
                ? this.getProduct(origin.department)
                : null,
            cost_center: origin.cost_center ? origin.cost_center : null,
            cost_center_name: origin.cost_center_title
                ? origin.cost_center_title
                : null,
            status: origin.status,
            current: origin.current,
        };
        return result;
    }

    private static getProduct(department: string): string {
        return department.split(" ")[0];
    }

    private static formatEnterDate_YYYYMMDD(enterDate: string): string {
        return [
            enterDate.substring(6, 8),
            enterDate.substring(4, 6),
            enterDate.substring(0, 4),
        ].join("-");
    }

    private static formatEnterDate_DDMMYYYY(enterDate: string): string {
        return [
            enterDate.substring(0, 4),

            enterDate.substring(4, 6),
            enterDate.substring(6, 8),
        ].join("-");
    }

    //End ----------------- Intra DB


    public static async SearchUser(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }

            const query = req.body;
            const offset = (query.pageNumber - 1) * query.pageSize;
            const limit = query.pageSize;

            const sortDefault = {
                column: "created_at",
                type: "DESC",
            };

            if (query.sort) {
                sortDefault.column = query.sort.column;
                sortDefault.type = query.sort.type;
            }

            const total = await UserController.userRepository
                .createQueryBuilder("user")
                .select("COUNT(user.*)", "total")
                .where("is_active =:is_active", { is_active: 1 })
                .getCount();

            const totalFound = await UserController.userRepository
                .createQueryBuilder("user")
                .select("COUNT(user.*)", "total")
                .where("is_active =:is_active", { is_active: 1 })
                .andWhere(query.searchStr ? qb => {
                    const searchStr = `%${query.searchStr.trim().toLowerCase()}%`;
                    qb.where("user.knox_id LIKE :searchStr", { searchStr })
                        .orWhere("user.employee_name LIKE :searchStr", { searchStr })
                        .orWhere("user.employee_no LIKE :searchStr", { searchStr });
                } : "1=1")
                .getCount();

            let result = await UserController.userRepository
                .createQueryBuilder("user")
                .select("user.*")
                .where("is_active =:is_active", { is_active: 1 })
                .andWhere(query.searchStr ? qb => {
                    const searchStr = `%${query.searchStr.trim().toLowerCase()}%`;
                    qb.where("user.knox_id LIKE :searchStr", { searchStr })
                        .orWhere("user.employee_name LIKE :searchStr", { searchStr })
                        .orWhere("user.employee_no LIKE :searchStr", { searchStr });
                } : "1=1")
                .groupBy("user.id")
                .offset(offset)
                .limit(limit)
                .orderBy(`user.${sortDefault.column}`, sortDefault.type as "DESC" | "ASC")
                .getRawMany();


            return res.status(200).json({
                message: "success",
                response: {
                    total: total,
                    totalFound: totalFound,
                    pageNumber: req.body.pageNumber,
                    pageSize: limit,
                    data: result,
                },
            });
        } catch (error) {
            return res
                .status(500)
                .json({ message: "Cannot search Intra User", error: error });
        }
    }

    public static async setAdminRoleMultiRows(req: any, res: any) {
        // create transaction
        // const trx = await db.transaction();
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }
            const errorIds: number[] = [];
            const successIds: number[] = [];
            const ids = req.body.ids;
            const knox_ids = req.body.knox_ids;
            if (ids && ids.length <= 0) {
                return res.status(400).json({ message: "Ids array is empty " });
            }
            if (knox_ids && knox_ids.length <= 0) {
                return res
                    .status(400)
                    .json({ message: "Knox_ids array is empty " });
            }

            for (let i = 0; i < ids.length; i++) {
                try {
                    const payload: SetAdminRolePayloadModel = {
                        is_admin: true,
                        set_role_by: req.body.modified_by,
                        set_role_at: yyyyMMdd_Long_Format(new Date()),
                        modified_by: req.body.modified_by,
                        modified_at: yyyyMMdd_Long_Format(new Date()),
                    };

                    // await trx(DATA_TABLE_NAME.USER)
                    //     .where("id", ids[i])
                    //     .andWhere("knox_id", knox_ids[i])
                    //     .update(payload);

                    await UserController.userRepository
                        .createQueryBuilder()
                        .update(User)
                        .set(payload)
                        .where("id = :id", { id: ids[i] })
                        .andWhere("knox_id = :knox_id", { knox_id: knox_ids[i] })
                        .execute();

                    successIds.push(ids[i]);
                } catch (err) {
                    errorIds.push(ids[i]);
                }
            }
            if (errorIds.length > 0) {
                // await trx.rollback();
                return res
                    .status(400)
                    .json({ message: "Cannot set admin role", errorIds });
            } else {
                // commit transaction
                // await trx.commit();
                return res.status(200).json({ message: "success", successIds });
            }
        } catch (error) {
            return res
                .status(400)
                .json({ message: "Error can not set admin role user", error });
        }
    }

    public static async inActiveMultiUsers(req: any, res: any) {
        // create transaction
        // const trx = await db.transaction();
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }
            const errorIds: number[] = [];
            const successIds: number[] = [];
            const ids = req.body.ids;
            const knox_ids = req.body.knox_ids;
            if (ids && ids.length <= 0) {
                return res.status(400).json({ message: "Ids array is empty " });
            }
            if (knox_ids && knox_ids.length <= 0) {
                return res
                    .status(400)
                    .json({ message: "Knox_ids array is empty " });
            }

            for (let i = 0; i < ids.length; i++) {
                try {
                    const payload: InActivePayloadModel = {
                        is_active: false,
                        is_admin: false,
                        set_role_by: null,
                        set_role_at: null,
                        modified_by: req.body.modified_by,
                        modified_at: yyyyMMdd_Long_Format(new Date()),
                    };

                    await UserController.userRepository
                        .createQueryBuilder()
                        .update(User)
                        .set(payload)
                        .where("id = :id", { id: ids[i] })
                        .andWhere("knox_id = :knox_id", { knox_id: knox_ids[i] })
                        .execute();

                    successIds.push(ids[i]);
                } catch (err) {
                    errorIds.push(ids[i]);
                }
            }
            if (errorIds.length > 0) {
                return res
                    .status(400)
                    .json({ message: "Cannot inactive users", errorIds });
            } else {
                return res.status(200).json({ message: "success", successIds });
            }
        } catch (error) {
            return res
                .status(400)
                .json({ message: "Error can not inactive user", error });
        }
    }

    public static async addNewUser(req: any, res: any) {
        try {
            const body = req.body;
            const userParsed = {
                employee_no: body.employee_no,
                knox_id: body.knox_id,
                employee_name: body.employee_name,
                employee_email: body.employee_email,
            };
            const newUser = await UserController.userRepository
                .createQueryBuilder()
                .insert()
                .into(User)
                .values(userParsed)
                .execute();
            return res.status(200).json({
                message: "success",
                newUser
            });
        } catch (error) {
            return res
                .status(500)
                .json({ message: "Cannot search Intra User", error: error });
        }
    }
}
