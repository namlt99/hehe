import { validationResult } from "express-validator";
import { AppDataSource } from "../configs/data-source";
import { InspectorInformation } from "../entities/InspectorInformation";
import { Attachment } from "../entities/Attachment";
import { Plant } from "../entities/Plant";
import { Process } from "../entities/Process";
import { ProcessDetail } from "../entities/ProcessDetail";
import { CertificateStatus } from "../entities/CertificateStatus";
import { ddMMyyyy_Short_Format, yyyyMMdd_Long_Format } from "../helper/dateHandler";
import { InspectorOriginModel, InspectorResultModel, RegisterCertificatePayloadModel, SetStatusInspectorPayloadModel } from "../models/InspectorModel";
import { CERTIFICATE_STATUS } from "../constants/CertificateStatusConst";
import { checkFileType } from "../midlewares/attachment.midleware";
import fs from "fs";
import { FILE_CONFIG } from "../configs/config";
import { AttachmentPayloadModel } from "../models/AttachmentModel";
import { endOfDay, startOfDay } from "date-fns";

export class InspectorController {
    private static inspectorRepository = AppDataSource.getRepository(InspectorInformation)
    constructor() { }
    /**
     * searchInspectors
     */
    public static async searchInspectors(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }
            const query = req.body;
            const offset = (req.body.pageNumber - 1) * req.body.pageSize;
            const limit = req.body.pageSize;

            const sortDefault = {
                column: "created_at",
                type: "DESC",
            };

            if (query.sort) {
                sortDefault.column = query.sort.column;
                sortDefault.type = query.sort.type;
            }
            const totalCount = await InspectorController.inspectorRepository
                .createQueryBuilder("inspectorinformation")
                .select("COUNT(inspectorinformation.*)", "total")
                .where("inspectorinformation.is_active = :is_active", { is_active: true })
                .getCount();


            const totalFound = await InspectorController.inspectorRepository
                .createQueryBuilder("inspectorinformation")
                .leftJoin(Attachment, "attachment", "inspectorinformation.id = attachment.inspector.id AND attachment.is_active = 1")
                .leftJoin(Plant, "plant", "plant.id = inspectorinformation.plant.id")
                .leftJoin(Process, "process", "process.id = inspectorinformation.process.id")
                .leftJoin(ProcessDetail, "processDetail", "processDetail.id = inspectorinformation.process_detail.id")
                .leftJoin(CertificateStatus, "certificateStatus", "certificateStatus.id = inspectorinformation.certificate_status.id")
                .where("inspectorinformation.is_active = :is_active", { is_active: true })
                .andWhere(query.gbm ? "inspectorinformation.gbm = :gbm" : "1=1", { gbm: query.gbm }) // Kiểm tra nếu query.gbm tồn tại
                .andWhere(query.plant_id ? "inspectorinformation.plant.id = :plantId" : "1=1", { plantId: query.plant_id })
                .andWhere(query.process_id ? "inspectorinformation.process.id = :processId" : "1=1", { processId: query.process_id })
                .andWhere(query.process_detail_id ? "inspectorinformation.process_detail.id = :processDetailId" : "1=1", { processDetailId: query.process_detail_id })
                .andWhere(query.certificate_status_id ? "inspectorinformation.certificate_status.id = :certificateStatusId" : "1=1", { certificateStatusId: query.certificate_status_id })
                .andWhere(query.searchStr ? qb => {
                    const searchStr = `%${query.searchStr.trim().toLowerCase()}%`;
                    qb.where("inspectorinformation.knox_id LIKE :searchStr", { searchStr })
                        .orWhere("inspectorinformation.employee_name LIKE :searchStr", { searchStr })
                        .orWhere("inspectorinformation.employee_no LIKE :searchStr", { searchStr });
                } : "1=1")
                .getCount();

            let result = await InspectorController.inspectorRepository
                .createQueryBuilder("inspectorinformation")
                .select([
                    "inspectorinformation.*",
                    "plant.name as plant_name",
                    "process.name as process_name",
                    "processDetail.name as process_detail_name",
                    "certificateStatus.name as certificate_status_name",
                    "DATEDIFF(inspectorinformation.next_certificate_date, NOW()) as delay",
                    "GROUP_CONCAT(attachment.file_name) AS file_names",
                    "GROUP_CONCAT(attachment.file_name_unique) AS file_name_uniques",
                    "GROUP_CONCAT(attachment.id) AS file_ids"
                ])
                .leftJoin(Attachment, "attachment", "inspectorinformation.id = attachment.inspector.id AND attachment.is_active = 1")
                .leftJoin(Plant, "plant", "plant.id = inspectorinformation.plant.id")
                .leftJoin(Process, "process", "process.id = inspectorinformation.process.id")
                .leftJoin(ProcessDetail, "processDetail", "processDetail.id = inspectorinformation.process_detail.id")
                .leftJoin(CertificateStatus, "certificateStatus", "certificateStatus.id = inspectorinformation.certificate_status.id")
                .where("inspectorinformation.is_active = :is_active", { is_active: 1 })
                .andWhere(query.gbm ? "inspectorinformation.gbm = :gbm" : "1=1", { gbm: query.gbm })
                .andWhere(query.plant_id ? "inspectorinformation.plant.id = :plantId" : "1=1", { plantId: query.plant_id })
                .andWhere(query.process_id ? "inspectorinformation.process.id = :processId" : "1=1", { processId: query.process_id })
                .andWhere(query.process_detail_id ? "inspectorinformation.process_detail.id = :processDetailId" : "1=1", { processDetailId: query.process_detail_id })
                .andWhere(query.certificate_status_id ? "inspectorinformation.certificate_status.id = :certificateStatusId" : "1=1", { certificateStatusId: query.certificate_status_id })
                .andWhere(query.searchStr ? qb => {
                    const searchStr = `%${query.searchStr.trim().toLowerCase()}%`;
                    qb.where("inspectorinformation.knox_id LIKE :searchStr", { searchStr })
                        .orWhere("inspectorinformation.employee_name LIKE :searchStr", { searchStr })
                        .orWhere("inspectorinformation.employee_no LIKE :searchStr", { searchStr });
                } : "1=1")
                .groupBy("inspectorinformation.id")
                .offset(offset)
                .limit(limit)
                .orderBy(`inspectorinformation.${sortDefault.column}`, sortDefault.type as "DESC" | "ASC")
                .getRawMany();
            if (!result) {
                return res.status(200).json({
                    message: "No search results",
                    total: totalCount,
                });
            }
            result = result.map((e) => {
                return InspectorController.formatInspectorSearch(e);
            });
            return res.status(200).json({
                message: "success",
                // result
                response: {
                    total: totalCount,
                    totalFound: totalFound,
                    pageNumber: req.body.pageNumber,
                    pageSize: limit,
                    data: result,
                },
            });
        } catch (error) {
            return res
                .status(500)
                .json({ message: "Error searching data", error });
        }
    }

    /**
     * getInspectorById
     */
    public static async getInspectorById(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }
            const result = await InspectorController.getById(Number.parseInt(req.query.id))

            if (!result) {
                return res
                    .status(400)
                    .json({ message: "Not Found Inspector by Id" });
            }
            const inspector = {
                ...result,
                file_names: result.file_names?.split(","),
                file_ids: result.file_ids?.split(","),
                file_name_uniques: result.file_name_uniques?.split(","),
            };
            return res.status(200).json(inspector);
        } catch (error) {
            return res
                .status(500)
                .json({ message: "Cannot get Inspector by Id", error: error });
        }
    }

    /***
     * addNewInspector
     */
    public static async addNewInspector(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }
            const body = req.body;
            // const inforUser = await UserController.getIntraUserInfo(
            //     body.knox_id,
            //     body.employee_no
            // );
            const inforUser = {
                employee_name: 'Lý Thành Nam',
                team: 'DA S/W R&D G',
                gbm: 'DA',
                product: 'Mobile',
                part: 'Mobile S/W',
                enter_date: '2022-08-22'
            }
            if (!inforUser) {
                return res.status(400).json({ message: "Not exist knox_id" });
            }

            // Lấy instance của các entity liên quan
            const plant = await AppDataSource.getRepository(Plant).findOneByOrFail({ id: body.plant_id });
            const process = await AppDataSource.getRepository(Process).findOneByOrFail({ id: body.process_id });
            const processDetail = await AppDataSource.getRepository(ProcessDetail).findOneByOrFail({ id: body.process_detail_id });
            const certificateStatus = await AppDataSource.getRepository(CertificateStatus).findOneByOrFail({ id: body.certificate_status_id });

            const newRecord = {
                employee_no: body.employee_no,
                knox_id: body.knox_id,
                employee_name: inforUser.employee_name,
                employee_team: inforUser.team,
                gbm: inforUser.gbm,
                product: inforUser.product || null,
                part: inforUser.part || null,
                enter_date: yyyyMMdd_Long_Format(inforUser.enter_date),
                remark: body.remark ? body.remark : null,
                created_by: body.created_by,
                plant: plant,
                process: process,
                process_detail: processDetail,
                certificate_status: certificateStatus,
            }

            const newInspectorId = await InspectorController.inspectorRepository.createQueryBuilder().insert().into(InspectorInformation).values(newRecord).execute();
            if (!newInspectorId) {
                return res
                    .status(400)
                    .json({ message: "Can not add new inspector" });
            }

            return res.status(200).json({ message: "success", newInspectorId });
        } catch (error) {
            return res
                .status(500)
                .json({ message: "Error add new data", error: error });
        }
    }

    /**
     * registerCertificate
     */
    public static async registerCertificate(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }

            // insert file
            const errorFiles: Object[] = [];
            const successFiles: Object[] = [];
            const files = req.files;
            if (files && files.length <= 0) {
                return res
                    .status(400)
                    .json({ message: "Files array is empty " });
            }
            for (const file of files) {
                try {
                    if (!checkFileType(file)) {
                        fs.unlinkSync(
                            `${FILE_CONFIG.publish_path}/ ${file.filename}`
                        );
                        return res.status(400).json({
                            message:
                                "Error: Only pdf and doc files are allowed",
                        });
                    } else {
                        const inspector = await InspectorController.inspectorRepository.findOneByOrFail({ id: req.body.id });
                        const AttachmentPayload = {
                            file_name: file.originalname,
                            file_name_unique: file.filename,
                            mime_type: file.mimetype,
                            file_size: file.size,
                            created_at: yyyyMMdd_Long_Format(new Date()),
                            created_by: req.body.registrant_knox_id,
                            inspector: inspector
                        };
                        await AppDataSource.getRepository(Attachment).createQueryBuilder().insert().into(Attachment).values(AttachmentPayload).execute();

                        successFiles.push({
                            originalName: file.originalname,
                            fileName: file.filename,
                            type: file.mimetype,
                        });
                    }
                } catch (err) {
                    errorFiles.push({
                        originalName: file.originalname,
                        fileName: file.filename,
                        type: file.mimetype,
                    });
                }
            }
            if (errorFiles.length > 0) {
                return res.status(400).json({
                    message: "Error: Only pdf and doc files are allowed haha",
                    errorFiles,
                });
            }
            const certificate_status_id = InspectorController.setCertificateStatus(
                req.body.next_certificate_date
            );

            // Lấy instance của các entity liên quan
            const certificateStatus = await AppDataSource.getRepository(CertificateStatus).findOneByOrFail({ id: certificate_status_id });
            const registerCertificatePayload =
            {
                pass_score: req.body.pass_score,
                start_date: yyyyMMdd_Long_Format(req.body.start_date),
                end_date: yyyyMMdd_Long_Format(req.body.end_date),
                last_certificate_date: yyyyMMdd_Long_Format(
                    req.body.last_certificate_date
                ),
                next_certificate_date: yyyyMMdd_Long_Format(
                    req.body.next_certificate_date
                ),
                register_date: yyyyMMdd_Long_Format(new Date()),
                modified_at: yyyyMMdd_Long_Format(new Date()),

                registrant_no: req.body.registrant_no,
                registrant_knox_id: req.body.registrant_knox_id,
                registrant_name: req.body.registrant_name,
                certificate_status: certificateStatus,
            };


            const updatedInspector = await InspectorController.inspectorRepository
                .createQueryBuilder()
                .update(InspectorInformation)
                .set(registerCertificatePayload)
                .where("id = :id", { id: req.body.id })
                .andWhere("is_active = :is_active", { is_active: 1 })
                .execute();


            if (!updatedInspector) {
                return res.status(400).json({
                    message: "Cannot register certificate",
                });
            }


            const getInspectorUpdated = await InspectorController.getById(req.body.id);

            const result =
                InspectorController.formatInspectorSearch(getInspectorUpdated);
            return res.status(200).json({ message: "success", result });
        } catch (error) {
            return res.status(500).json({
                message: "Error",
                error,
            });
        }
    }

    /**
     * updateInspectorCertificate
     */
    public static async updateInspectorCertificate(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }
            const errorFiles: Object[] = [];
            const successFiles: Object[] = [];
            const query = req.body;
            const files = req.files;
            const fileDeleteIds = query.fileDeleteIds
                ? JSON.parse(query.fileDeleteIds)
                : null;

            const certificate_status_id = InspectorController.setCertificateStatus(
                req.body.next_certificate_date
            );
            const certificateStatus = await AppDataSource.getRepository(CertificateStatus).findOneByOrFail({ id: certificate_status_id });
            const registerCertificatePayload =
            {
                pass_score: req.body.pass_score,
                start_date: yyyyMMdd_Long_Format(req.body.start_date),
                end_date: yyyyMMdd_Long_Format(req.body.end_date),
                last_certificate_date: yyyyMMdd_Long_Format(
                    req.body.last_certificate_date
                ),
                next_certificate_date: yyyyMMdd_Long_Format(
                    req.body.next_certificate_date
                ),
                modified_by: query.modified_by,
                modified_at: yyyyMMdd_Long_Format(new Date()),

                certificate_status: certificateStatus,
            };


            const updatedInspector = await InspectorController.inspectorRepository
                .createQueryBuilder()
                .update(InspectorInformation)
                .set(registerCertificatePayload)
                .where("id = :id", { id: req.body.id })
                .andWhere("is_active = :is_active", { is_active: 1 })
                .execute();

            if (!updatedInspector) {
                return res.status(400).json({
                    message: "Cannot register certificate",
                });
            }

            if (fileDeleteIds && fileDeleteIds.length > 0) {
                let filesToDelete = fileDeleteIds.map((e) =>
                    Number.parseInt(e)
                );
                for (let fileId of filesToDelete) {
                    try {
                        await AppDataSource.getRepository(Attachment)
                            .createQueryBuilder()
                            .update(Attachment)
                            .set({ is_active: false })
                            .where("id = :id", { id: fileId })
                            .execute();
                    } catch (error) {
                        console.log(error);
                    }
                }
            }

            if (files && files.length > 0) {
                for (const file of files) {
                    try {
                        if (!checkFileType(file)) {
                            fs.unlinkSync(
                                `${FILE_CONFIG.publish_path}/ ${file.filename}`
                            );
                            return res.status(400).json({
                                message:
                                    "Error: Only pdf and doc files are allowed",
                            });
                        } else {
                            const inspector = await InspectorController.inspectorRepository.findOneByOrFail({ id: req.body.id });
                            const AttachmentPayload = {
                                file_name: file.originalname,
                                mime_type: file.mimetype,
                                file_name_unique: file.filename,
                                file_size: file.size,
                                created_at: yyyyMMdd_Long_Format(new Date()),
                                created_by: query.modified_by,
                                inspector: inspector
                            };
                            await AppDataSource.getRepository(Attachment).createQueryBuilder().insert().into(Attachment).values(AttachmentPayload).execute();



                            successFiles.push({
                                originalName: file.originalname,
                                fileName: file.filename,
                                type: file.mimetype,
                            });
                        }
                    } catch (err) {
                        errorFiles.push({
                            originalName: file.originalname,
                            fileName: file.filename,
                            type: file.mimetype,
                        });
                    }
                }
            }

            if (errorFiles.length > 0) {
                return res.status(400).json({
                    message: "Error: Only pdf and doc files are allowed",
                    errorFiles,
                });
            }

            // commit transaction

            const getInspectorUpdated = await InspectorController.getById(query.id);
            const result =
                InspectorController.formatInspectorSearch(getInspectorUpdated);
            return res.status(200).json({ message: "success", result });
        } catch (error) {
            // rollback transaction on error
            return res.status(500).json({
                message: "Error",
                error,
            });
        }
    }

    /**
     * inActiveMultiRows
     */
    public static async inActiveMultiRows(req: any, res: any) {
        // create transaction
        // const trx = await db.transaction();
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }

            const errorIds: number[] = [];
            const successIds: number[] = [];
            const body = req.body;
            const ids = body.ids;
            if (ids && ids.length <= 0) {
                return res.status(400).json({ message: "Ids array is empty " });
            }
            for (const id of ids) {
                try {
                    const payload: SetStatusInspectorPayloadModel = {
                        is_active: false,
                        modified_by: body.deleted_by,
                        modified_at: yyyyMMdd_Long_Format(new Date()),
                    };


                    await InspectorController.inspectorRepository
                        .createQueryBuilder()
                        .update(InspectorInformation)
                        .set(payload)
                        .where("id = :id", { id: id })
                        .execute();

                    successIds.push(id);
                } catch (err) {
                    errorIds.push(id);
                }
            }
            if (errorIds.length > 0) {
                return res
                    .status(400)
                    .json({ message: "Cannot delete inspectors", errorIds });
            } else {
                // commit transaction
                return res.status(200).json({ message: "success", successIds });
            }
        } catch (error) {
            // rollback transaction on error
            return res
                .status(500)
                .json({ message: "Error register certificate", error: error });
        }
    }

    /**
     * activeMultiRows
     */
    public static async activeMultiRows(req: any, res: any) {

        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }

            const errorIds: number[] = [];
            const successIds: number[] = [];
            const ids = req.body.ids;
            if (ids && ids.length <= 0) {
                return res.status(400).json({ message: "Ids array is empty " });
            }
            for (const id of ids) {
                try {
                    const payload: SetStatusInspectorPayloadModel = {
                        is_active: true,
                        modified_by: req.body.actived_by,
                        modified_at: yyyyMMdd_Long_Format(new Date()),
                    };

                    await InspectorController.inspectorRepository
                        .createQueryBuilder()
                        .update(InspectorInformation)
                        .set(payload)
                        .where("id = :id", { id: id })
                        .execute();

                    successIds.push(id);
                } catch (err) {
                    errorIds.push(id);
                }
            }
            if (errorIds.length > 0) {
                return res
                    .status(400)
                    .json({ message: "Cannot active inspectors", errorIds });
            } else {
                // commit transaction
                return res.status(200).json({ message: "success", successIds });
            }
        } catch (error) {
            // rollback transaction on error
            return res
                .status(500)
                .json({ message: "Error register certificate", error: error });
        }
    }

    public static async testApi(req: any, res: any) {
        try {
            // const { from, to } = req.query;
            const result = await InspectorController.getListOfOverdueCertificates();
            return res.status(200).json({ message: "success", result });
        } catch (error) {
            // rollback transaction on error
            return res
                .status(500)
                .json({ message: "Error register certificate", error: error });
        }
    }


    public static async setStatusIsPlanWhenLessThen30Days() {
        try {
            const certificateStatus = await AppDataSource.getRepository(CertificateStatus).findOneByOrFail({ id: 3 as any });
            await InspectorController.inspectorRepository
                .createQueryBuilder()
                .update(InspectorInformation)
                .set({ certificate_status: certificateStatus, modified_at: yyyyMMdd_Long_Format(new Date()) })
                .where("is_active = :is_active", { is_active: 1 })
                .andWhere("DATEDIFF(DATE_ADD(CURDATE(), INTERVAL 30 DAY), next_certificate_date) >= 0")
                .andWhere("datediff(next_certificate_date, now()) >= 0")
                .andWhere("inspectorinformation.certificateStatusId <> :certificateStatusId", { certificateStatusId: 3 as any })
                .execute();
        } catch (error) {
            console.log(error)
        }
    }

    public static async setStatusIsDelayWhenCertOutOfDate() {
        try {
            const certificateStatus = await AppDataSource.getRepository(CertificateStatus).findOneByOrFail({ id: 4 as any });
            await InspectorController.inspectorRepository
                .createQueryBuilder("inspectorinformation")
                .update(InspectorInformation)
                .set({ certificate_status: certificateStatus })
                .where("is_active = :is_active", { is_active: 1 })
                .andWhere("datediff(next_certificate_date, now()) < 0")
                .andWhere("inspectorinformation.certificateStatusId <> :certificateStatusId", { certificateStatusId: 4 as any })
                .execute();
        } catch (error) {
            console.log(error)
        }
    }

    public static async getListOfOverdueCertificates() {
        return await InspectorController.inspectorRepository
            .createQueryBuilder("inspectorinformation")
            .select([
                "ROW_NUMBER() OVER() as no",
                "inspectorinformation.*",
                "plant.name AS plant_name",
                "process.name AS process_name",
                "processDetail.name AS process_detail_name",
                "certificateStatus.name AS certificate_status_name",
                "DATEDIFF(inspectorinformation.next_certificate_date, NOW()) AS delay",
            ]
            )
            .leftJoin(Plant, "plant", "plant.id = inspectorinformation.plant.id")
            .leftJoin(Process, "process", "process.id = inspectorinformation.process.id")
            .leftJoin(ProcessDetail, "processDetail", "processDetail.id = inspectorinformation.process_detail.id")
            .leftJoin(CertificateStatus, "certificateStatus", "certificateStatus.id = inspectorinformation.certificate_status.id")
            .groupBy("inspectorinformation.id")
            .where("inspectorinformation.is_active = :is_active", { is_active: 1 })
            .andWhere(
                "DATEDIFF(DATE_ADD(CURDATE(), INTERVAL 30 DAY), inspectorinformation.next_certificate_date) >= 0" // return all inspector that have certificate out of date <=30
            )
            .andWhere("inspectorinformation.certificate_status.id <> :certificateStatusId", { certificateStatusId: 3 as any })
            .getRawMany();

    }


    public static async getInspectorListFromTo(from: string, to: string) {
        return await InspectorController.inspectorRepository
            .createQueryBuilder("inspectorinformation")
            .select([
                "ROW_NUMBER() OVER() as no",
                "inspectorinformation.*",
                "plant.name AS plant_name",
                "process.name AS process_name",
                "processDetail.name AS process_detail_name",
                "certificateStatus.name AS certificate_status_name",
                "DATEDIFF(inspectorinformation.next_certificate_date, NOW()) AS delay",
            ]

            )
            .leftJoin(Plant, "plant", "plant.id = inspectorinformation.plant.id")
            .leftJoin(Process, "process", "process.id = inspectorinformation.process.id")
            .leftJoin(ProcessDetail, "processDetail", "processDetail.id = inspectorinformation.process_detail.id")
            .leftJoin(CertificateStatus, "certificateStatus", "certificateStatus.id = inspectorinformation.certificate_status.id")
            .groupBy("inspectorinformation.id")
            .where("inspectorinformation.is_active = :is_active", { is_active: 1 })
            .andWhere("inspectorinformation.created_at BETWEEN :startDate AND :endDate", {
                startDate: yyyyMMdd_Long_Format(startOfDay(from)),
                endDate: yyyyMMdd_Long_Format(endOfDay(to))
            })
            .getRawMany();
    }

    public static async getById(_id: number): Promise<any> {
        return await InspectorController.inspectorRepository
            .createQueryBuilder("inspectorinformation")
            .select([
                "inspectorinformation.*",
                "plant.name AS plant_name",
                "process.name AS process_name",
                "processDetail.name AS process_detail_name",
                "certificateStatus.name AS certificate_status_name",
                "DATEDIFF(inspectorinformation.next_certificate_date, NOW()) AS delay",
                "GROUP_CONCAT(attachment.file_name) AS file_names",
                "GROUP_CONCAT(attachment.file_name_unique) AS file_name_uniques",
                "GROUP_CONCAT(attachment.id) AS file_ids"
            ])
            .leftJoin(Attachment, "attachment", "inspectorinformation.id = attachment.inspector.id AND attachment.is_active = 1")
            .leftJoin(Plant, "plant", "plant.id = inspectorinformation.plant.id")
            .leftJoin(Process, "process", "process.id = inspectorinformation.process.id")
            .leftJoin(ProcessDetail, "processDetail", "processDetail.id = inspectorinformation.process_detail.id")
            .leftJoin(CertificateStatus, "certificateStatus", "certificateStatus.id = inspectorinformation.certificate_status.id")
            .where("inspectorinformation.id = :id", { id: _id })
            .andWhere("inspectorinformation.is_active = :is_active", { is_active: 1 })
            .groupBy("inspectorinformation.id")
            .getRawOne();
    };


    private static setCertificateStatus(nextCert: any) {
        const today = new Date();
        const next_certificate_date = new Date(nextCert);
        const leftTimes = next_certificate_date.getTime() - today.getTime();
        const leftDays = Math.ceil(leftTimes / (1000 * 60 * 60 * 24));
        if (leftDays <= 30 && leftDays >= 0) {
            return CERTIFICATE_STATUS.PLAN;
        } else if (leftDays < 0) {
            return CERTIFICATE_STATUS.DELAY;
        }
        return CERTIFICATE_STATUS.COMPLETE;
    }

    public static formatInspectorSearch(origin: InspectorOriginModel) {
        const result: InspectorResultModel = {
            ...origin,
            start_date: origin.start_date
                ? ddMMyyyy_Short_Format(origin.start_date)
                : null,
            end_date: origin.end_date
                ? ddMMyyyy_Short_Format(origin.end_date)
                : null,
            register_date: origin.register_date
                ? ddMMyyyy_Short_Format(origin.register_date)
                : null,
            last_certificate_date: origin.last_certificate_date
                ? ddMMyyyy_Short_Format(origin.last_certificate_date)
                : null,
            next_certificate_date: origin.next_certificate_date
                ? ddMMyyyy_Short_Format(origin.next_certificate_date)
                : null,
            created_at: origin.created_at
                ? ddMMyyyy_Short_Format(origin.created_at)
                : null,
            modified_at: origin.modified_at
                ? ddMMyyyy_Short_Format(origin.modified_at)
                : null,
            enter_date: origin.enter_date
                ? ddMMyyyy_Short_Format(origin.enter_date)
                : null,
            file_names: origin.file_names?.split(","),
            file_ids: origin.file_ids?.split(","),
            file_name_uniques: origin.file_name_uniques?.split(","),
        };

        return result;
    }

    public static formatDelay(delay: string): string {
        const abc = Number.parseInt(delay);
        if (!Number.isNaN(abc)) {
            return delay.toString();
        }
        return "";
    }
}