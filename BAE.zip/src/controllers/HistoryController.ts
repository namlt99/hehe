import { validationResult } from "express-validator";
import { AppDataSource } from "../configs/data-source";
import { DATA_TABLE_NAME } from "../constants/DataTableConst";
import { History } from "../entities/History";
import { HistoryDetailModel, HistoryModel } from "../models/HistoryModel";

const hightlightColor = "#dc3545";

export class HistoryController {
    private static historyRepository = AppDataSource.getRepository(History)

    constructor() { }

    public static async searchHistory(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }
            const query = req.body;
            const offset = (query.pageNumber - 1) * query.pageSize;
            const limit = query.pageSize;
            const sortDefault = {
                column: "timestamp",
                type: "DESC",
            };
            if (query.sort) {
                sortDefault.column = query.sort.column;
                sortDefault.type = query.sort.type;
            }
            const totalCount = await HistoryController.historyRepository
                .createQueryBuilder("history")
                .select("COUNT(history.id)", "total")
                .getCount();

            const totalFound = await HistoryController.historyRepository
                .createQueryBuilder("history")
                .select("COUNT(history.id)", "total")
                .where((qb) => {
                    if (query.table_name) {
                        qb.andWhere("history.table_name = :table_name", { table_name: query.table_name });
                    }
                    if (query.knox_id) {
                        const knoxIdParam = `%${query.knox_id}%`;
                        qb.andWhere("(history.new_data ->> '$.created_by' LIKE :knoxIdParam OR history.new_data ->> '$.modified_by' LIKE :knoxIdParam OR history.new_data ->> '$.knox_id' LIKE :knoxIdParam OR history.new_data ->> '$.set_role_by' LIKE :knoxIdParam)", { knoxIdParam: knoxIdParam })

                    }
                })
                .getCount();

            const historyList = await HistoryController.historyRepository
                .createQueryBuilder("history")
                .select("history.*")
                .where((qb) => {
                    if (query.table_name) {
                        qb.andWhere("history.table_name = :table_name", { table_name: query.table_name });
                    }
                    if (query.knox_id) {
                        const knoxIdParam = `%${query.knox_id}%`;
                        qb.andWhere("(history.new_data ->> '$.created_by' LIKE :knoxIdParam OR history.new_data ->> '$.modified_by' LIKE :knoxIdParam OR history.new_data ->> '$.knox_id' LIKE :knoxIdParam OR history.new_data ->> '$.set_role_by' LIKE :knoxIdParam)", { knoxIdParam: knoxIdParam })

                    }
                })
                .groupBy("history.id")
                .offset(offset)
                .limit(limit)
                .orderBy(`history.${sortDefault.column}`, sortDefault.type as "DESC" | "ASC")
                .getRawMany();

            const result = historyList.map((e) => {
                return HistoryController.formatHistoryData(e);
            });
            return res.status(200).json({
                message: "success",
                response: {
                    total: totalCount,
                    totalFound: totalFound,
                    pageNumber: req.body.pageNumber,
                    pageSize: limit,
                    data: result,
                },
            });
        } catch (error) {
            return res
                .status(500)
                .json({ message: "Error cannot search History", error });
        }
    }

    public static async getHistoryDetailById(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }
            let result = await HistoryController.historyRepository
                .createQueryBuilder("history")
                .select("history.*")
                .where("history.id = :id", { id: req.body.id })
                .getRawOne();

            if (!result) {
                return res.status(400).json({
                    message: "Not exsist History with id" + req.body.id,
                });
            }
            result = HistoryController.formatHistoryDetail(result);
            return res.status(200).json({
                message: "success",
                result,
            });
        } catch (error) {
            return res
                .status(500)
                .json({ message: "Error cannot search History by Id", error });
        }
    }

    private static formatHistoryDetail(origin: any) {
        const result: HistoryDetailModel = {
            id: origin.id,
            table_name: origin.table_name,
            old_data: JSON.parse(origin.old_data),
            new_data: JSON.parse(origin.new_data),
            log: this.getLog(origin),
            action: this.formatInspectorAction(origin),
        };
        return result;
    }

    private static formatHistoryData(origin: any) {
        const result: HistoryModel = {
            id: origin.id,
            table_name: origin.table_name,
            action: this.formatInspectorAction(origin),
            log: this.getLog(origin),
            timestamp: origin.timestamp,
        };
        return result;
    }

    private static getLog(origin: any): string {
        if (!origin) return null;
        const new_data = JSON.parse(origin.new_data);
        const old_data = JSON.parse(origin.old_data);
        let log: string;

        if (old_data) {
            if (origin.table_name === DATA_TABLE_NAME.INSPECTOR_INFORMATION) {
                if (new_data.is_active === 0) {
                    log = `<span>Inspector <span style="color: ${hightlightColor};"> ${old_data.knox_id} </span> has been deleted by <span style="color: ${hightlightColor};"> ${new_data.modified_by} </span></span>`;
                } else {
                    // update certificate -> co 2 truong hop => (add new certificate) va (update certificate)
                    if (!new_data.modified_by) {
                        // add new certificate
                        log = `<span>Inspector <span style="color: ${hightlightColor};"> ${old_data.knox_id} </span> has been added certificate by <span style="color: ${hightlightColor};"> ${new_data.registrant_knox_id} </span></span>`;
                    } else {
                        // update certificate
                        log = `<span>Inspector <span style="color: ${hightlightColor};"> ${old_data.knox_id} </span> has been updated certificate by <span style="color: ${hightlightColor};"> ${new_data.modified_by} </span></span>`;
                    }
                }
            }
            if (origin.table_name === DATA_TABLE_NAME.USER) {
                if (new_data.is_active === 0 && new_data.is_admin === 0) {
                    // xoa
                    log = `<span><span style="color: ${hightlightColor};"> ${old_data.knox_id} </span> has been deleted by <span style="color: ${hightlightColor};"> ${new_data.modified_by} </span></span>`;
                } else if (
                    // xoa tai khoan, va dang ki lai
                    new_data.is_active === 1 &&
                    new_data.is_admin === 0
                ) {
                    log = `<span>User <span style="color: ${hightlightColor};"> ${new_data.knox_id} </span> has been registered account again</span>`;
                } else {
                    // set admin role
                    log = ` <span><span style="color: ${hightlightColor};"> ${old_data.knox_id} </span> has been assigned Admin role by <span style="color: ${hightlightColor};">${new_data.modified_by} </span></span>`;
                }
            }
        } else {
            if (origin.table_name === DATA_TABLE_NAME.INSPECTOR_INFORMATION) {
                log = `<span>Inspector <span style="color: ${hightlightColor};"> ${new_data.knox_id} </span> has been created by <span style="color: ${hightlightColor};"> ${new_data.created_by} </span></span>`;
            }
            if (origin.table_name === DATA_TABLE_NAME.USER) {
                log = `<span>User <span style="color: ${hightlightColor};"> ${new_data.knox_id} </span> has been registered new account</span>`;
            }
        }
        return log;
    }

    private static formatInspectorAction(origin: any) {
        const new_data = JSON.parse(origin.new_data);
        if (
            (origin.table_name === DATA_TABLE_NAME.INSPECTOR_INFORMATION &&
                origin.action === "update" &&
                new_data.is_active === 0) ||
            (origin.table_name === DATA_TABLE_NAME.USER &&
                origin.action === "update" &&
                new_data.is_active === 0 && new_data.is_admin === 0)
        ) {
            return "delete";
        }
        return origin.action;
    }
}