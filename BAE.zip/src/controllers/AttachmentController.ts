import { validationResult } from "express-validator";
import fs from "fs";
import { FILE_CONFIG } from "../configs/config";
import { AppDataSource } from "../configs/data-source";
import { Attachment } from "../entities/Attachment";
import { v4 as uuidv4 } from "uuid";
import { InspectorController } from "./InspectorController";
import { Workbook } from "exceljs";
import { MMMMddyyyy_Short_Format, ddMMyyyy_Short_Format } from "../helper/dateHandler";
import { ExportExcelModel } from "../models/InspectorModel";

export class AttactmentController {
    private static attachmentRepository = AppDataSource.getRepository(Attachment)
    
    constructor(){}
    
    public static async downloadCertifitate(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ message: "validation error" });
            }
            const { fileNameUnique, id } = req.query;

            const existFile = await AttactmentController.attachmentRepository.findOneByOrFail({id: id, file_name_unique: fileNameUnique})
            if (!existFile)
                return res.status(404).json({ message: "File not found" });

            const file = `${FILE_CONFIG.publish_path}/${fileNameUnique}`;

            if (!fs.existsSync(file)) {
                return res
                    .status(404)
                    .json({ message: "File not found in publish folder" });
            }

            const fileStream = fs.createReadStream(file);
            res.setHeader("Content-Type", "application/octet-stream");
            res.setHeader(
                "Content-Disposition",
                "attachment; filename=" + fileNameUnique
            );

            fileStream.pipe(res);
        } catch (error) {
            return res
                .status(500)
                .json({ message: "Error download attachment", error: error });
        }
    }

    public static async exportExcel(req: any, res: any) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res
                    .status(400)
                    .json({ message: "validation error", errors });
            }
            const { from, to } = req.query;
            let data = await InspectorController.getInspectorListFromTo(
                from,
                to
            );
            const workbook = new Workbook();
            const commonName = `Inspector List ${MMMMddyyyy_Short_Format(
                from
            )} - ${MMMMddyyyy_Short_Format(to)}`;

            data = data.map((e) =>
                AttactmentController.formatDataToExportExcel(e)
            );

            const worksheet = workbook.addWorksheet(
                `${MMMMddyyyy_Short_Format(from)} - ${MMMMddyyyy_Short_Format(
                    to
                )}`
            );

            // create header
            const columns = [
                { header: "No", key: "no", width: 5 },
                { header: "Knox ID", key: "knox_id", width: 15 },
                { header: "Name", key: "name", width: 30 },
                { header: "Team", key: "team", width: 25 },
                { header: "Part", key: "part", width: 20 },
                { header: "GBM", key: "gbm", width: 7 },
                { header: "Plant", key: "plant", width: 20 },
                { header: "Product", key: "product", width: 20 },
                { header: "Enter Date", key: "enter_date", width: 20 },
                { header: "Process", key: "process", width: 15 },
                { header: "Detail Process", key: "detail_process", width: 20 },
                { header: "Remark", key: "remark", width: 30 },
                {
                    header: "Last Certification",
                    key: "last_certification",
                    width: 20,
                },
                { header: "Pass Score", key: "pass_score", width: 10 },
                {
                    header: "Next Certification",
                    key: "next_certification",
                    width: 20,
                },
                { header: "Status", key: "status", width: 25 },
                { header: "Remaining days", key: "delay", width: 15 },
            ];

            // add header
            worksheet.columns = columns;

            // fill data
            data.forEach((row) => {
                worksheet.addRow(row);
            });

            // set style for each row
            worksheet.eachRow((row) => {
                row.height = 25;
                row.eachCell((cell) => {
                    cell.alignment = { vertical: "middle" };
                    cell.border = {
                        top: { style: "thin" },
                        left: { style: "thin" },
                        bottom: { style: "thin" },
                        right: { style: "thin" },
                    };
                });
            });

            // add style
            const headerRow = worksheet.getRow(1);
            headerRow.font = { bold: true };
            headerRow.fill = {
                type: "pattern",
                pattern: "solid",
                fgColor: { argb: "eaecfb" },
            };

            // set style for special column
            const specialColumns = [1, 9, 13, 14, 15, 17];
            specialColumns.forEach((columnIndex) => {
                const column = worksheet.getColumn(columnIndex);
                column.eachCell((cell) => {
                    cell.alignment = {
                        horizontal: "center",
                        vertical: "middle",
                    };
                });
            });

            // alignment header
            headerRow.alignment = { horizontal: "center", vertical: "middle" };

            // set background color for delay column
            const delayColumn = worksheet.getColumn(17);
            delayColumn.eachCell((cell, rowNumber) => {
                if (rowNumber !== 1) {
                    if (!cell.value) {
                        cell.fill = {
                            type: "pattern",
                            pattern: "solid",
                            fgColor: { argb: "ffffff" },
                        };
                    } else {
                        if (cell.value) {
                            cell.fill =
                                AttactmentController.styleForRemainingDaysColumn(
                                    cell.value.toString()
                                );
                            cell.font = { color: { argb: "ffffff" } };
                        }
                    }
                }
            });

            const filename = `${uuidv4()}-${commonName}.xlsx`;
            const filePath = `${FILE_CONFIG.publish_path}/${filename}`;
            await workbook.xlsx.writeFile(filePath).then(() => {
                res.download(filePath, (err) => {
                    if (err) {
                        console.log(err);
                    } else {
                        fs.unlinkSync(filePath);
                        console.log("export success");
                    }
                });
            });
        } catch (error) {
            return res.status(500).json({ message: "error", error: error });
        }
    }

    private static styleForRemainingDaysColumn(delay: string): any {
        const remaningdays = Number.parseInt(delay);
        if (remaningdays >= 0) {
            if (remaningdays <= 30) {
                return {
                    type: "pattern",
                    pattern: "solid",
                    fgColor: { argb: "ffa500" },
                };
            }
            return {
                type: "pattern",
                pattern: "solid",
                fgColor: { argb: "18864b" },
            };
        } else {
            return {
                type: "pattern",
                pattern: "solid",
                fgColor: { argb: "cb3837" },
            };
        }
    }

    public static formatDataToExportExcel(origin: any) {
        const result: ExportExcelModel = {
            no: origin.no,
            knox_id: origin.knox_id,
            name: origin.employee_name,
            team: origin.employee_team,
            part: origin.part ? origin.part : "",
            gbm: origin.gbm,
            product: origin.product ? origin.product : "",
            enter_date: ddMMyyyy_Short_Format(origin.enter_date),
            
            plant: origin.plant_name,
            process: origin.process_name,
            detail_process: origin.process_detail_name,

            remark: origin.remark ? origin.remark : "",
            last_certification: origin.last_certificate_date
                ? ddMMyyyy_Short_Format(origin.last_certificate_date)
                : "",
            pass_score: origin.pass_score ? origin.pass_score : "",
            next_certification: origin.next_certificate_date
                ? ddMMyyyy_Short_Format(origin.next_certificate_date)
                : "",
            status: origin.certificate_status_name,
            delay: InspectorController.formatDelay(origin.delay),
        };

        return result;
    }
}

