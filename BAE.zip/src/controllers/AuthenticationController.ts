import axios, { AxiosResponse } from "axios";
import { AddNewUserPayloadModel, UserModel } from "src/models/UserModel";
import { User } from "../entities/User";
import { AppDataSource } from "../configs/data-source";
import { yyyyMMdd_Long_Format } from "../helper/dateHandler";
import { JWTTokenService } from "../services/JWTService";

export class AuthenticationController {
    private static userRepository = AppDataSource.getRepository(User)

    constructor() { }

    public static async loginSSO(req: any, res: any) {
        const _un = new Date().getTime() - new Date().getMilliseconds();
        const uri = `http://107.118.212.71/intranet/users/api_login/?un=${_un}`;

        const response: AxiosResponse = await axios.post(
            uri,
            {
                sso: req.body.data,
                type: "socket",
            },
            {
                headers: {
                    "Content-Type":
                        "application/x-www-form-urlencoded; charset=UTF-8",
                },
            }
        );
        if (response.status !== 200) {
            return res.status(response.status).json({ message: "error" });
        }

        const originUserInfo = response.data.user;

        if (!originUserInfo || !originUserInfo.EP_LOGINID) {
            return res
                .status(401)
                .json({ message: "Please login samsung.net first" });
        }

        const userParsed: UserModel = {
            employee_no: originUserInfo.EP_SABUN,
            knox_id: originUserInfo.EP_LOGINID,
            employee_name: originUserInfo.EP_USERNAME,
            employee_email: originUserInfo.EP_MAIL,
        };

        const existUser = await AuthenticationController.userRepository
            .createQueryBuilder('user')
            .select('user.*')
            .where("user.knox_id =:knox_id", { knox_id: userParsed.knox_id })
            .getRawOne();
        // .select("*")
        // .where({
        //     knox_id: userParsed.knox_id,
        // })
        // .first();

        let user = { ...userParsed };

        if (!existUser) {
            const addNewUserPayload: AddNewUserPayloadModel = {
                ...userParsed,
            };
            const newUser = await AuthenticationController.userRepository
                .createQueryBuilder()
                .insert()
                .into(User)
                .values(addNewUserPayload)
                .execute();

            if (!newUser) {
                return res.status(400).json({ message: "Cannot add new user" });
            }
        } else {
            let updateUser = existUser;
            if (!existUser.is_active) {
                const UpdatePayload = {
                    is_active: true,
                    modified_at: yyyyMMdd_Long_Format(),
                };

                updateUser = await AuthenticationController.userRepository
                .createQueryBuilder()
                    .update(User)
                    .set(UpdatePayload)
                    .where("knox_id = :knox_id", { knox_id: userParsed.knox_id })
                    .execute();
            }
            user = Object.assign(user, updateUser);
        }
        const result = {
            employee_no: user.employee_no,
            knox_id: user.knox_id,
            employee_name: user.employee_name,
            employee_email: user.employee_email,
            id: user.id,
            is_admin: user.is_admin,
            is_active: user.is_active,
        };

        const accessToken = await JWTTokenService.generateAccessToken(result);
        // const accessToken = JWTTokenService.genToken(result);
        // const accessToken = await jwt.sign(user, "nam", { expiresIn: "1h" });
        return res.status(200).json({ message: "success", accessToken });
    }

    public static async logoutSSO(req: any, res: any) {
        //handle logout
        return res.status(200).json({ message: "Logout success" });
    }
}
