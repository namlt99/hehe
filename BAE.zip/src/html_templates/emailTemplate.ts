export const header = `<table class="cui-div" style="border-collapse: collapse;"><colgroup><col></colgroup><tbody><tr><td class="mail_wrap cui-div-cell" style="border: 0px solid grey;"><p class="mail_header"><img src="https://qweb.sec.samsung.net/cs/csqCommon/images/mail/mail_logo.gif" unselectable="on" data-cui-image="true" style="border-width: 0px;"></p>
<table class="cui-div" style="border-collapse: collapse;"><colgroup><col></colgroup><tbody><tr><td class="mail_content cui-div-cell" style="border: 0px solid grey;"><p style="width:100%;padding: 5px 5px 5px 5px; color:#474641;font-size:12px;"><b>검사원 인증 유효기간이 만료 또는 만료될 예정이오니<br>
			  신속히 재인증을 진행하여 주시기 바랍니다.<br>
		</b></p>
<p style="width:100%;padding: 5px 5px 5px 5px; color:#474641;font-size:12px;"><b>As the validity period of the inspector certification has expired or is scheduled to expire,<br>
			 please proceed with the inspector re-certification promptly.<br>
		</b></p>
<h1>List of inspectors</h1>
<table class="cui-div" style="border-collapse: collapse;">
  <colgroup>
    <col>
  </colgroup>
  <tbody>
    <tr>
      <td class="mail_body cui-div-cell" style="border: 0px solid grey;">
        <table class="detail cui-real-table" style="width: 100%; border-collapse: collapse;">
          <colgroup>
            <col style="width: 25px;">
            <col style="width: 75px;">
            <col style="width: 75px;">
            <col style="width: 138px;">
            <col style="width: 88px;">
            <col style="width: 100px;">
            <col style="width: 88px;">
            <col style="width: 88px;">
            <col style="width: 100px;">
            <col style="width: 100px;">
            <col style="width: 100px;">
            <col style="width: 138px;">
            <col style="width: 63px;">
          </colgroup>
        <tbody>
        <tr>
    <th style="width: 2%; border: 0px solid grey;"><p>No </p>
  </th><th style="width: 8%; border: 0px solid grey;"><p>Employee<br>No. </p>
  </th><th style="width: 10%; border: 0px solid grey;"><p>Name </p>
  </th><th style="width: 11%; border: 0px solid grey;"><p>Team </p>
  </th><th style="width: 7%; border: 0px solid grey;"><p>GBM </p>
  </th><th style="width: 8%; border: 0px solid grey;"><p>Plant </p>
  </th><th style="width: 9%; border: 0px solid grey;"><p>Product </p>
  </th><th style="width: 10%; border: 0px solid grey;"><p>Process </p>
  </th><th style="width: 10%; border: 0px solid grey;"><p>Detail<br>Process </p>
  </th><th style="width: 8%; border: 0px solid grey;"><p>Last<br>Certification </p>
  </th><th style="width: 8%; border: 0px solid grey;"><p>Next<br>Certification </p></th>
  <th style="width: 11%; border: 0px solid grey;"><p>Status </p></th>
  <th style="width: 5%; border: 0px solid grey;"><p>Delay </p></th>
</tr>
`;

export const body = `<tr>
<td style="text-align: center; border: 0px solid grey;" class="cui-real-td"><p><%= inspectorList[i].no%></p>
</td><td style="text-align: center; border: 0px solid grey;" class="cui-real-td"><p><%= inspectorList[i].employee_no%></p>
</td><td class="cui-real-td" style="border: 0px solid grey;"><p><%= inspectorList[i].name%></p>
</td><td class="cui-real-td" style="border: 0px solid grey;"><p><%= inspectorList[i].team%></p>
</td><td class="cui-real-td" style="border: 0px solid grey;"><p><%= inspectorList[i].gbm%></p>
</td><td class="cui-real-td" style="border: 0px solid grey;"><p><%= inspectorList[i].plant%></p>
</td><td class="cui-real-td" style="border: 0px solid grey;"><p><%= inspectorList[i].product%></p>
</td><td class="cui-real-td" style="border: 0px solid grey;"><p><%= inspectorList[i].process%></p>
</td><td class="cui-real-td" style="border: 0px solid grey;"><p><%= inspectorList[i].detail_process%></p>
</td><td style="text-align: center; border: 0px solid grey;" class="cui-real-td"><p><%= inspectorList[i].last_certification%></p>
</td><td style="text-align: center; border: 0px solid grey;" class="cui-real-td"><p><%= inspectorList[i].next_certification%></p>
</td><td style="text-align: center; border: 0px solid grey;" class="cui-real-td"><p><%= inspectorList[i].status%></p>
</td><td style="background-color: orange; text-align: center; border: 0px solid grey;" class="cui-real-td"><p><span style="color: white;">-<%= inspectorList[i].delay%></span></p></td>
</tr>`;

export const footer = `<!-- </td></tr></tbody></table><p class="buttonsection"><span class="button email"><a href="https://qweb.sec.samsung.net" target="_blank">Q-WEB SYSTEM</a></span></p> -->
</td></tr></tbody></table><p class="mail_footer">Copyright ⓒ2011 SAMSUNG. All rights reserved.</p>
</td></tr></tbody></table></td></tr></tbody></table>`;
