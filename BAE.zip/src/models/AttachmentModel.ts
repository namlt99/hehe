export interface AttachmentModel {
    id: number;
    file_name: string;
    file_name_unique: string;
    mime_type: string;
    file_size: number;
    inspector_id: number;
    created_at: string;
    is_actived: boolean;
    created_by: string;
}

export interface AttachmentPayloadModel {
    file_name: string;
    file_name_unique: string;
    mime_type: string;
    file_size: number;
    inspector_id?: number;
    created_at?: string;
    is_active?: boolean;
    created_by: string;
}



