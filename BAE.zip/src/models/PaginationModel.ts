export interface PaginationModel{
  pageSize: number;
  pageNumber: number;
}