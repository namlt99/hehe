export interface HistoryModel {
    id: number;
    action: string;
    table_name: string;
    log: string;
    timestamp: string;
}

export interface HistoryDetailModel {
    id: number;
    action: string;
    table_name: string;
    log: string;
    old_data: Object;
    new_data: Object;
}