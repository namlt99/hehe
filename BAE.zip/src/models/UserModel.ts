export interface UserSearchModel {
    knox_id: string;
    employee_no: string;
    employee_name: string;
    employee_name_en: string;
    employee_email: string;
    gender: string;
    phone: string;
    team: string | null;
    group: string | null;
    part: string | null;
    enter_date: string | null;
    gbm: string;
    product: string | null;
    cost_center: string | null;
    cost_center_name: string | null;
    status: boolean;
    current: string;
}

export interface UserModel {
    id?: number;
    employee_no: string;
    knox_id: string;
    employee_name: string;
    employee_email: string;
    is_admin?: boolean;
    status?: string;
    is_active?: boolean;
    created_by?: string;
    created_at?: string;
    modified_by?: string;
    modified_at?: string;
}

export interface AddNewUserPayloadModel {
    employee_no: string;
    knox_id: string;
    employee_name: string;
    employee_email: string;
    is_active?: boolean;
    created_at?: string;
}

export interface SetAdminRolePayloadModel {
    is_admin: boolean;
    set_role_by: string;
    set_role_at: string;
    modified_by: string;
    modified_at: string;
}

export interface InActivePayloadModel {
    is_active: boolean;
    is_admin: boolean;
    set_role_by: string;
    set_role_at: string;
    modified_by: string;
    modified_at: string;
}
