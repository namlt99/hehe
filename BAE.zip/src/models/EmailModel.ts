export interface EmailPayloadModel{
  subject: string;
  body:string;
  sender:string;
  receivers:string;
  created: Date;
}