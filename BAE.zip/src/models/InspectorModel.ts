export interface InspectorOriginModel {
    id: number;
    employee_no: string;
    knox_id: string;
    employee_name: string;
    employee_team: string;
    gbm: string;
    product: string;
    part: string;
    enter_date: string;

    pass_score: number;
    start_date: string;
    end_date: string;
    last_certificate_date: string;
    next_certificate_date: string;
    delay: number;
    remark: string;
    is_active: boolean;

    registrant_no: string;
    registrant_knox_id: string;
    registrant_name: string;
    register_date: string;

    created_by: string;
    created_at: string;
    modified_by: string;
    modified_at: string;

    plant_id: number;
    process_id: number;
    process_detail_id: number;
    certificate_status_id: number;

    file_names: string;
    file_ids: string;
    file_name_uniques: string;
}

export interface InspectorResultModel {
    id: number;
    employee_no: string;
    knox_id: string;
    employee_name: string;
    employee_team: string;
    gbm: string;
    product: string;
    part: string;
    enter_date: string;

    pass_score: number;
    start_date: string;
    end_date: string;
    last_certificate_date: string;
    next_certificate_date: string;
    delay: number;
    remark: string;
    is_active: boolean;

    registrant_no: string;
    registrant_knox_id: string;
    registrant_name: string;
    register_date: string;

    created_by: string;
    created_at: string;
    modified_by: string;
    modified_at: string;

    plant_id: number;
    process_id: number;
    process_detail_id: number;
    certificate_status_id: number;

    file_names: string[];
    file_ids: string[];
    file_name_uniques: string[];
}

export interface InspectorSearch {
    pageSize: number;
    pageNumber: number;
    employee_no?: string;
    knox_id?: string;
    gbm_id?: number;
    plant_id?: number;
    process_id?: number;
    process_detail_id?: number;
    certificate_status_id?: number;
}

export interface AddNewInspectorPayloadModel {
    employee_no: string;
    knox_id: string;
    employee_name: string;
    employee_team: string;
    gbm: string;
    product?: string;
    part?: string;
    enter_date: string;

    plant_id: number;
    process_id: number;
    process_detail_id: number;
    certificate_status_id: number;
    remark?: string;
    is_active: boolean;
    created_at: string;
    created_by: string;
}

export interface RegisterCertificatePayloadModel {
    // id: number;
    pass_score: number;
    start_date: string;
    end_date: string;
    last_certificate_date: string;
    next_certificate_date: string;
    register_date: string;
    modified_at: string;
    certificate_status_id?: number;
    registrant_no: string;
    registrant_knox_id: string;
    registrant_name: string;
}

export interface UpdateCertificatePayloadModel {
    // id: number;
    pass_score: number;
    start_date: string;
    end_date: string;
    last_certificate_date: string;
    next_certificate_date: string;
    register_date: string;
    modified_at: string;
    certificate_status_id?: number;
    modified_by: string;
}

export interface SetStatusInspectorPayloadModel {
    is_active: boolean;
    modified_by: string;
    modified_at: string;
}

export interface ExportExcelModel {
    no: number;
    employee_no?:string;
    knox_id: string;
    name: string;
    team: string;
    part: string;
    gbm: string;
    plant: string;
    product: string;
    enter_date: string;
    process: string;
    detail_process: string;
    remark: string;
    last_certification: string;
    pass_score: number;
    next_certification: string;
    status: string;
    delay: string;
}
