export interface SearchCriteriaModel{
  fieldName: string;
  value: any;
}