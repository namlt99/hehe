import multer from "multer";
import path from "path";
import { FILE_CONFIG } from "../configs/config";
import { v4 as uuidv4 } from "uuid";

const storage = multer.diskStorage({
    destination: FILE_CONFIG.publish_path, // can be changed to any folder
    filename: (req, file: Express.Multer.File, cb) => {
        const filename = `${uuidv4()}-${file.originalname}`; //unique name
        cb(null, filename);
    },
});

export const upload = multer({
    storage,
    limits: { fileSize: FILE_CONFIG.max_size },
});

export function checkFileType(file: Express.Multer.File) {
    const filetypes = FILE_CONFIG.publish_type;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(
        path.extname(file.originalname).toLocaleLowerCase()
    );
    
    const maximumSize = 10 << 20;
    // console.log(mimetype, extname, file.size <= maximumSize)
    
    if (mimetype && extname && file.size <= maximumSize) {
        return true;
    } else {
        return false;
    }
}
