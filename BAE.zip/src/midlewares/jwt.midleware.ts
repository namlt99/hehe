import { JWTTokenService } from "../services/JWTService";
import { ACCESS_TOKEN_CONFIG } from "../configs/config";
import * as jwt from "jsonwebtoken";
import jwtSimple from "jwt-simple";
import { isAfter, parse } from "date-fns";
export class VerifyToken {
    public static async verifyAccessToken(req: any, res: any, next: any) {
        const authHeader =
            req.headers.authorization || req.headers.Authorization;
        if (!authHeader && !authHeader?.startsWith("Bearer "))
            return res
                .status(401)
                .json({ message: "Access token is missing!" });
        const accessToken = authHeader.split(" ")[1];
        console.log(accessToken);
        await JWTTokenService.verifyToken(accessToken, (err, response) => {
            if (err)
                return res
                    .status(401)
                    .json({ message: "Access token had expired time!" });

            return next();
        });
    }

    public static authenVerify(req: any, res: any, next: any) {
        const authHeader =
            req.headers.authorization || req.headers.Authorization;
        if (!authHeader && !authHeader?.startsWith("Bearer "))
            return res
                .status(401)
                .json({ message: "Access token is missing!" });
        const accessToken = authHeader.split(" ")[1];
        try {
            const decode = jwtSimple.decode(
                accessToken,
                ACCESS_TOKEN_CONFIG.token
            );
            const expireTIme = parse(
                decode.exp,
                "yyyy-MM-dd HH:mm:ss",
                new Date()
            );
            if(!isAfter(expireTIme, new Date())){
                return res
                .status(401)
                .json({ message: "Access token had expired time!" });
            }
            return next();
        } catch (err) {
            return res
                    .status(401)
                    .json({ message: "Invalid token" });
        }
    }
}
