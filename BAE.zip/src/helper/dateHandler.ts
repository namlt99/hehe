
import { format } from "date-fns";

export const yyyyMMdd_Long_Format = (date: any = new Date()) => {
  return format(new Date(date),"yyyy-MM-dd HH:mm:ss");
}

export const ddMMyyyy_Long_Format = (date: any = new Date()) => {
  return format(new Date(date),"dd-MM-yyyy HH:mm:ss");
}

export const MMMMddyyyy_Short_Format = (date: any = new Date()) => {
  return format(new Date(date),"MMMM dd yyyy");
}

export const ddMMyyyy_Short_Format = (date: any = new Date()) => {
  return format(new Date(date),"dd-MM-yyyy");
}
