
import { InspectorValidation } from "../validators/InspectorValidation";
import { InspectorController } from "../controllers/InspectorController";
import { upload } from "../midlewares/attachment.midleware";
// import { VerifyToken } from "../middlewares/verifyJWT";

export class InspectorRouter {
  app;
  private static readonly baseUrl = "/inspector";

  constructor(_app) {
    this.app = _app;

    this.configRouter();
  }

  private configRouter() {
    this.app.post(
      this._buildUrl("searchInspectors"),
      InspectorValidation.PagingValidator(),
      InspectorController.searchInspectors
    );
    this.app.get(
      this._buildUrl("getInspectorById"),
      InspectorValidation.getByIdValidator(),
      // VerifyToken.verifyAccessToken,
      InspectorController.getInspectorById
    );
    this.app.post(
      this._buildUrl("addNewInspector"),
      InspectorValidation.AddNewInspectorValidator(),
      // VerifyToken.verifyAccessToken,
      InspectorController.addNewInspector
    );
   
    this.app.post(
      this._buildUrl("registerCertificate"),
      upload.array('files'),
      InspectorValidation.RegisterCertValidator(),
      // VerifyToken.verifyAccessToken,
      InspectorController.registerCertificate
    );

    this.app.post(
      this._buildUrl("updateInspectorCertificate"),
      upload.array('files'),
      InspectorValidation.UpdateCertValidator(),
      // VerifyToken.verifyAccessToken,
      InspectorController.updateInspectorCertificate
    );

    this.app.post(
      this._buildUrl("inActiveMultiRows"),
      InspectorValidation.InActiveMultiRowsValidator(),
      // VerifyToken.verifyAccessToken,
      InspectorController.inActiveMultiRows
    );

    this.app.post(
      this._buildUrl("activeMultiRows"),
      InspectorValidation.ActiveMultiRowsValidator(),
      // VerifyToken.verifyAccessToken,
      InspectorController.activeMultiRows
    );

    this.app.get(
      this._buildUrl("testApi"),
      // VerifyToken.verifyAccessToken,
      InspectorController.testApi
    );
  }

  private _buildUrl(url: string): string {
    return `${InspectorRouter.baseUrl}/${url}`;
  }
}
