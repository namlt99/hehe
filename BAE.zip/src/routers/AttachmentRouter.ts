// import { VerifyToken } from "../middlewares/verifyJWT";

import { AttactmentController } from "../controllers/AttachmentController";
import { AttachmentValidation } from "../validators/AttachmentValidation";

export class AttachmentRouter {
    app;
    private static readonly baseUrl = "/attachment";

    constructor(_app) {
        this.app = _app;

        this.configRouter();
    }

    private configRouter() {
        this.app.get(
            this._buildUrl("downloadAttachment"),
            AttachmentValidation.DownloadAttachmentValidator(),
            // VerifyToken.verifyAccessToken,
            AttactmentController.downloadCertifitate
        );

        this.app.get(
            this._buildUrl("exportExcel"),
            AttachmentValidation.ExportExcelValidator(),
            // VerifyToken.verifyAccessToken,
            AttactmentController.exportExcel
        );
    }

    private _buildUrl(url: string): string {
        return `${AttachmentRouter.baseUrl}/${url}`;
    }
}
