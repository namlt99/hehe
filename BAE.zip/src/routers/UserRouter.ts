
import { UserValidation } from "../validators/UserValidation";
import { UserController } from "../controllers/UserController";
// import { UserValidation } from "../validations/UserValidation";

export class UserRouter {
    app;
    private static readonly baseUrl = "/user";

    constructor(_app) {
        this.app = _app;

        this.configRouter();
    }

    private configRouter() {
        //--------------- Intra DB

         // this.app.post(
        //     this._buildUrl("searchIntraUser"),
        //     UserValidation.SearchIntraUserValidator(),
        //     // VerifyToken.verifyAccessToken,
        //     UserController.SearchIntraUser
        // );

        // -----------------------

        this.app.post(
            this._buildUrl("searchUser"),
            UserValidation.SearchUserValidator(),
            //   VerifyToken.verifyAccessToken,
            // VerifyToken.authenVerify,
            UserController.SearchUser
        );
        this.app.post(
            this._buildUrl("addNewUser"),
            //   VerifyToken.verifyAccessToken,
            // VerifyToken.authenVerify,
            UserController.addNewUser
        );

        this.app.post(
            this._buildUrl("setAdminRoleMultiRows"),
            UserValidation.ChangeStatusValidator(),
            // VerifyToken.verifyAccessToken,
            UserController.setAdminRoleMultiRows
        );
        
        this.app.post(
            this._buildUrl("inActiveMultiUsers"),
            UserValidation.ChangeStatusValidator(),
            // VerifyToken.verifyAccessToken,
            UserController.inActiveMultiUsers
        );

       

        
        // this.app.get(
        //     this._buildUrl("getAllUser"),
        //     //   VerifyToken.verifyAccessToken,
        //     // VerifyToken.authenVerify,
        //     UserController.getAllUser
        // );
    }

    private _buildUrl(url: string): string {
        return `${UserRouter.baseUrl}/${url}`;
    }
}
