import { AuthenticationController } from "../controllers/AuthenticationController";

export class AuthenticationRouter {
    app;
    private static readonly baseUrl = "/authentication";

    constructor(_app) {
        this.app = _app;

        this.configRouter();
    }

    private configRouter() {
        this.app.post(
            this._buildUrl("loginsso"),
            // AuthenticationValidation.AuthenticationValidator,
            AuthenticationController.loginSSO
        );
    }

    private _buildUrl(url: string): string {
        return `${AuthenticationRouter.baseUrl}/${url}`;
    }
}
