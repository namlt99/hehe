import { HistoryController } from "../controllers/HistoryController";
import { HistoryValidation } from "../validators/HistoryValidation";


export class HistoryRouter {
    app;
    private static readonly baseUrl = "/history";

    constructor(_app) {
        this.app = _app;

        this.configRouter();
    }
    private configRouter() {
        this.app.post(
            this._buildUrl("searchHistory"),
            HistoryValidation.GetHistoryValidator(),
            // VerifyToken.verifyAccessToken,
            HistoryController.searchHistory
        );
        this.app.post(
            this._buildUrl("getHistoryById"),
            HistoryValidation.GetHistoryByIdValidator(),
            // VerifyToken.verifyAccessToken,
            HistoryController.getHistoryDetailById
        );
    }

    private _buildUrl(url: string): string {
        return `${HistoryRouter.baseUrl}/${url}`;
    }
}
