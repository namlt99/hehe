import { NgModule } from '@angular/core';
import { UserTableRoutingModule } from './user-table-routing.module';

@NgModule({
    imports: [UserTableRoutingModule],
})
export class UserTableModule { }
