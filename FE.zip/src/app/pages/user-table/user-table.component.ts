import { SelectionModel } from '@angular/cdk/collections';
import { CommonModule, DatePipe, NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { _SelectSearchType } from '@core/models/common.model';
import { InActivePayloadModel, SetAdminRolePayload } from '@core/models/user.model';
import { AuthenticationService } from '@core/service/authentication.service';
import { UserService } from '@core/service/user.service';
import { BreadcrumbComponent } from '@shared/components/breadcrumb/breadcrumb.component';
import { FeatherIconsComponent } from '@shared/components/feather-icons/feather-icons.component';
import moment from 'moment';
import { debounceTime } from 'rxjs';
import { DeleteDialogComponent } from '../advance-table/dialogs/delete/delete.component';
import { MatDialog } from '@angular/material/dialog';
import { HTTP_RESPONSE_MESSAGE } from '@core/constant/helper.const';
import { SetAdminRoleConfirmComponent } from './set-admin-role-confirm/set-admin-role-confirm.component';
import { ToastrService } from '@core/service/toastr.service';

@Component({
  selector: 'app-user-table',
  standalone: true,
  imports: [
    BreadcrumbComponent,
    MatTooltipModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatSortModule,
    NgClass,
    MatCheckboxModule,
    FeatherIconsComponent,
    MatRippleModule,
    MatProgressSpinnerModule,
    MatMenuModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    DatePipe,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
  ],
  templateUrl: './user-table.component.html',
  styleUrl: './user-table.component.scss',
})
export class UserTableComponent {
  displayedColumns = ['no', 'employee_no', 'knox_id', 'employee_name', 'employee_email', 'is_admin', 'set_role_by', 'set_role_at'];
  SelectSearchType = _SelectSearchType;
  totalUser = 0;
  // displayPageSize = 0;
  selection = new SelectionModel<any>(true, []);
  inspectorDataSource: MatTableDataSource<any> = new MatTableDataSource();
  searchForm: FormGroup;
  isAdmin: boolean = false;

  length = 0;
  // pageSize = 10;
  step: number = 0;

  searchPayload: any = {
    pageNumber: 1,
    pageSize: 10,
    searchStr: null,
  };

  constructor(
    private userService: UserService,
    private toastrService: ToastrService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    public authenticationService: AuthenticationService
  ) {
    this.createSearchForm();
    if (authenticationService.isAdmin) {
      this.displayedColumns.push('actions');
    }
  }

  ngOnInit() {
    this.searchUserList();

    // reset data when search text box empty
    this.searchForm.controls['searchStr'].valueChanges.pipe(debounceTime(500)).subscribe((res) => {
      if (!res) {
        this.searchUserList();
      }
    });
  }

  createSearchForm() {
    this.searchForm = this.fb.group({
      searchStr: [null],
    });
  }

  setAdminRole(user: any) {
    if (!this.authenticationService.isAdmin) return;

    const confirmDialog = this.dialog.open(SetAdminRoleConfirmComponent, {
      disableClose: true,
      data: user,
    });

    confirmDialog.afterClosed().subscribe((res: any) => {
      if (res === 1) {
        const payload: SetAdminRolePayload = {
          ids: [user.id],
          knox_ids: [user.knox_id],
          modified_by: this.authenticationService.currentUserValue.knox_id,
        };
        this.userService.setAdminRole(payload).subscribe((res: any) => {
          if (res && res.message === HTTP_RESPONSE_MESSAGE.SUCCESS) {
            this.searchUserList();
            this.toastrService.showNotification('snackbar-success', 'Set Admin role success');
          }
        });
      }
    });
  }

  inActiveUser(user: any) {
    if (!this.authenticationService.isAdmin) return;
    const deleteDialogComponent = this.dialog.open(DeleteDialogComponent, {
      disableClose: true,
      data: user,
      // direction: tempDirection,
    });

    deleteDialogComponent.afterClosed().subscribe((result) => {
      // result === 1 mean close = true
      if (result === 1) {
        const payload: InActivePayloadModel = {
          ids: [user.id],
          knox_ids: [user.knox_id],
          modified_by: this.authenticationService.currentUserValue.knox_id,
        };
        this.userService.inActiveMultiUsers(payload).subscribe((res: any) => {
          if (res && res.message === HTTP_RESPONSE_MESSAGE.SUCCESS) {
            this.searchUserList();
            this.toastrService.showNotification('snackbar-success', 'Delete User success');
            if (this.authenticationService.currentUserValue.knox_id === payload.knox_ids[0]) {
              this.authenticationService.logOut();
            }
          }
        });
      }
    });
  }

  searchUserList(isResetSearchForm: boolean = true) {

    const searchStr = this.searchForm.controls['searchStr'].value;
    if (searchStr) {
      this.searchPayload.searchStr = searchStr;
    }

    this.userService.searchUsers(this.searchPayload).subscribe((data: any) => {
      if (data && data.message === HTTP_RESPONSE_MESSAGE.SUCCESS && data.response.data.length > 0) {
        this.length = data.response.totalFound;
        this.step = (data.response.pageNumber - 1) * data.response.pageSize;

        const userList = data.response.data.map((e: any) => this.convertUserData(e));
        this.inspectorDataSource = new MatTableDataSource(userList);
      } else {
        this.inspectorDataSource = new MatTableDataSource(data.response.data);
        // show notify when no data found
        this.toastrService.showNotification('snackbar-danger', 'Can not find any User!');
      }

      // reset searchStr
      if (isResetSearchForm) {
        this.searchPayload.searchStr = null;
      }
    });
  }

  handlePageEvent(event: any) {
    this.searchPayload.pageNumber = event.pageIndex + 1;
    this.searchPayload.pageSize = event.pageSize;

    this.searchUserList(false);
  }

  convertUserData(origin: any) {
    const userData = {
      ...origin,
      set_role_at: origin.set_role_at ? moment(origin.set_role_at).format('DD-MM-YYYY HH:mm:ss') : '',
      modified_at: origin.modified_at ? moment(origin.modified_at).format('DD-MM-YYYY HH:mm:ss') : '',
    };
    return userData;
  }
}
