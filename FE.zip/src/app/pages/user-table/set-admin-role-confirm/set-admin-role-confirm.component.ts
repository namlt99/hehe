import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogActions, MatDialogClose, MatDialogContent, MatDialogRef, MatDialogTitle } from '@angular/material/dialog';
import { DialogData } from 'app/pages/advance-table/dialogs/delete/delete.component';

@Component({
  selector: 'app-set-admin-role-confirm',
  standalone: true,
  imports: [
    MatDialogTitle,
        MatDialogContent,
        MatDialogActions,
        MatButtonModule,
        MatDialogClose,
  ],
  templateUrl: './set-admin-role-confirm.component.html',
  styleUrl: './set-admin-role-confirm.component.scss'
})
export class SetAdminRoleConfirmComponent {
  constructor(
    public dialogRef: MatDialogRef<SetAdminRoleConfirmComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
  ) {
    // console.log('data', data);
  }
  cancel(): void {
    this.dialogRef.close();
  }
  confirm(){

  }
}
