import { NgModule } from '@angular/core';
import { AdvanceTableRoutingModule } from './advance-table-routing.module';

@NgModule({
    imports: [AdvanceTableRoutingModule],
})
export class AdvanceTableModule { }
