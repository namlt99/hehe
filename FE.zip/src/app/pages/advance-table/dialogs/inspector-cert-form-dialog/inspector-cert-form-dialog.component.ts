import { MAT_DIALOG_DATA, MatDialogRef, MatDialogContent, MatDialogClose } from '@angular/material/dialog';
import { Component, ElementRef, Inject, Input, ViewChild } from '@angular/core';
import { Validators, FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, AbstractControl, ValidatorFn } from '@angular/forms';
import { MAT_DATE_LOCALE, MatOptionModule } from '@angular/material/core';
import { AsyncPipe, CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatRadioModule } from '@angular/material/radio';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { _DetailProcess, _GBM, _Plant, _Process, _SelectSearchType, _Status } from '@core/models/common.model';
import { DialogDataModel } from '@core/models/Inspector.model';
import { AddNewFormDialogComponent } from '../add-new-form-dialog/add-new-form-dialog.component';
import { MaterialFileUploadComponent } from '@shared/components/material-file-upload/material-file-upload.component';
import { DomSanitizer } from '@angular/platform-browser';
import { CertForm } from '@core/models/cert-form';
import { InspectorService } from '@core/service/inspector.service';
import { DownloadCertPayload } from '@core/models/attachment.model';
import { AttachmentService } from '@core/service/attachment.service';
import { AuthenticationService } from '@core/service/authentication.service';
import moment from 'moment';
import { AddNewForm } from '@core/models/inspector-form';
import { ACTION, HTTP_RESPONSE_MESSAGE, LOCALE_CODE } from '@core/constant/helper.const';
import { ToastrService } from '@core/service/toastr.service';
import { provideMomentDateAdapter } from '@angular/material-moment-adapter';
export function ValidatorFiles(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const value = control.value;
    if (value === 0) {
      return { filesEmpty: true };
    }
    return null;
  };
}
@Component({
  selector: 'app-inspector-cert-form-dialog',
  standalone: true,
  templateUrl: './inspector-cert-form-dialog.component.html',
  styleUrl: './inspector-cert-form-dialog.component.scss',
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatDialogContent,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatRadioModule,
    MatDatepickerModule,
    MatSelectModule,
    MatOptionModule,
    MatDialogClose,
    MatAutocompleteModule,
    AsyncPipe,
    MaterialFileUploadComponent,
  ],
  providers: [{ provide: MAT_DATE_LOCALE, useValue: LOCALE_CODE.VN }, provideMomentDateAdapter()],
})
export class InspectorCertFormDialogComponent {
  @ViewChild('input') inputName: ElementRef<HTMLInputElement> | undefined;
  @ViewChild('fileUpload') fileUpload!: ElementRef<HTMLInputElement>;

  @Input() multiple: any;
  @Input() accept: any;
  @Input() deleteButtonLabel: any;

  // filteredOptions: Observable<string[]>;
  GBM = _GBM;
  Plant = _Plant;
  Process = _Process;
  DetailProcess = _DetailProcess;
  SelectSearchType = _SelectSearchType;
  Status = _Status;

  certForm: CertForm = new CertForm();
  certFormGroup!: FormGroup;

  downloadCertPayload: DownloadCertPayload;
  maxLengthCert: number = 0;
  fileNames: string[] = [];

  listCert: any = [];

  deletedFileIds: string[] = [];
  reqPayload = new FormData();
  // isDisplayCert: boolean = true;

  private _currentUser!: AddNewForm;

  selectedFiles: File[] = [];
  inputFileName: string | undefined;
  actionTitle: string = '';
  isFilesValid: boolean = true;

  constructor(
    public dialogRef: MatDialogRef<AddNewFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogDataModel: DialogDataModel,
    public inspectorService: InspectorService,
    private attachmentService: AttachmentService,
    private authenticationService: AuthenticationService,
    private toastrService: ToastrService,
    private formBuilder: FormBuilder,
    private sanitizer: DomSanitizer
  ) {
    if (dialogDataModel.action === 'add') {
      this.actionTitle = 'Create';
    } else {
      this.actionTitle = 'Save';
    }
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    const currentUserId = this.dialogDataModel.inspectorData[0].id;
    this.inspectorService.getInspectorById(currentUserId).subscribe((user: any) => {
      this._currentUser = user;
      this.createCertForm(user);

      if (user.hasOwnProperty('file_name_uniques') && user.hasOwnProperty('file_ids')) {
        for (let i = 0; i < user.file_ids.length; i++) {
          const fileInfo = {
            fileId: user.file_ids[i],
            fileNameUnique: user.file_name_uniques[i],
            fileName: user.file_names[i],
          };
          this.listCert.push(fileInfo);
        }
      }
      this.maxLengthCert = this.listCert.length + this.selectedFiles.length;
    });
  }

  onClickDownloadCertificate(idx: number) {
    this.downloadCertPayload = {
      file_name_unique: this._currentUser.file_name_uniques[idx],
      id: this._currentUser.file_ids[idx],
    };

    this.attachmentService.downloadCertificate(this.downloadCertPayload);
  }

  onClickDeleteCertificate(fileId: string) {
    this.listCert = this.listCert.filter((e: any) => e.fileId !== fileId);
    this.maxLengthCert--;
    this.certFormGroup.controls['fileNames'].setValue(this.maxLengthCert);
    this.deletedFileIds.push(fileId);
  }

  createCertForm(user: any) {
    this.certFormGroup = this.formBuilder.group({
      // Inspector Information
      id: [user.id],
      employee_name: [{ value: user.employee_name, disabled: true }],
      employee_team: [{ value: user.employee_team, disabled: true }],
      enter_date: [{ value: moment(new Date(user.enter_date)).format('DD-MM-yyyy'), disabled: true }],
      gbm: [{ value: user.gbm, disabled: true }],
      plant_name: [{ value: user.plant_name, disabled: true }],
      product: [{ value: user.product, disabled: true }],
      process_detail_name: [{ value: user.process_detail_name, disabled: true }],
      process_name: [{ value: user.process_name, disabled: true }],
      part: [{ value: user.part, disabled: true }],
      remark: [{ value: user.remark, disabled: true }],

      // Result Registration
      start_date: [user.start_date, Validators.required],
      end_date: [user.end_date, Validators.required],
      pass_score: [user.pass_score, Validators.required],
      last_certificate_date: [user.last_certificate_date, Validators.required],
      next_certificate_date: [{ value: user.next_certificate_date, disabled: true }, Validators.required],

      // Just for upload file
      fileNames: [user.file_name_uniques ? user.file_name_uniques.length : 0, [Validators.required, ValidatorFiles()]],

      // Creater cert infomation
      registrant_no: [
        { value: user.registrant_no ? user.registrant_no : this.authenticationService.currentUserValue.employee_no, disabled: true },
        Validators.required,
      ],
      registrant_knox_id: [
        { value: user.registrant_knox_id ? user.registrant_knox_id : this.authenticationService.currentUserValue.knox_id, disabled: true },
        Validators.required,
      ],
      registrant_name: [
        { value: user.registrant_name ? user.registrant_name : this.authenticationService.currentUserValue.employee_name, disabled: true },
        Validators.required,
      ],
    });
  }

  getSelectedStartDate(event: any) {
    const startDate = new Date(event.value);
    // Automatic +2 months
    const nextTwoMonth = new Date(startDate.setMonth(startDate.getMonth() + 2));
    this.certFormGroup.controls['end_date'].setValue(nextTwoMonth);
  }

  getSelectedLastCertDate(event: any) {
    const lastDate = new Date(event.value);
    // Automatic +2 years
    const nextTwoYear = new Date(lastDate.setFullYear(lastDate.getFullYear() + 2));
    this.certFormGroup.controls['next_certificate_date'].setValue(nextTwoYear);
  }

  validateKeyCode(event: any) {
    ['e', 'E', '+', '-'].includes(event.key) && event.preventDefault();
  }

  onClickTriggerInput(event: any) {
    if (this.fileUpload) this.fileUpload.nativeElement.click();
  }

  onClickCloseDialog(): void {
    this.dialogRef.close();
  }

  onClickModifyCert() {
    if (this.certFormGroup.invalid || !this.authenticationService.isAdmin) {
      return;
    }
    this.createCertificatePayload();
    // Add new certificate
    if (this.dialogDataModel.action === ACTION.ADD) {
      this.reqPayload.append('registrant_no', this.authenticationService.currentUserValue.employee_no);
      this.reqPayload.append('registrant_knox_id', this.authenticationService.currentUserValue.knox_id);
      this.reqPayload.append('registrant_name', this.authenticationService.currentUserValue.employee_name);

      this.inspectorService.registerCertificate(this.reqPayload).subscribe((data: any) => {
        if (data.message === HTTP_RESPONSE_MESSAGE.SUCCESS) {
          this.inspectorService.isSuccess.next(true);
          this.toastrService.showNotification('snackbar-success', 'Register certificate success');
        }
      });
    }

    // Update certificate
    if (this.dialogDataModel.action === ACTION.UPDATE) {
      this.reqPayload.append('modified_by', this.authenticationService.currentUserValue.knox_id);

      if (this.deletedFileIds && this.deletedFileIds.length > 0) {
        this.reqPayload.append('fileDeleteIds', JSON.stringify(this.deletedFileIds));
      }

      this.inspectorService.updateCertificate(this.reqPayload).subscribe((data: any) => {
        if (data.message === HTTP_RESPONSE_MESSAGE.SUCCESS) {
          this.inspectorService.isSuccess.next(true);
          this.toastrService.showNotification('snackbar-success', 'Update certificate infomation success');
        }
      });
    }
  }

  createCertificatePayload() {
    this.reqPayload.append('id', this.certFormGroup.controls['id'].value);
    this.reqPayload.append('start_date', this.certFormGroup.controls['start_date'].value);
    this.reqPayload.append('end_date', this.certFormGroup.controls['end_date'].value);
    this.reqPayload.append('pass_score', this.certFormGroup.controls['pass_score'].value);
    this.reqPayload.append('last_certificate_date', this.certFormGroup.controls['last_certificate_date'].value);
    this.reqPayload.append('next_certificate_date', this.certFormGroup.controls['next_certificate_date'].value);

    // append multi attachments
    // const files = this.certFormGroup.controls['files'].value;
    const files = this.selectedFiles;
    if (files && files.length > 0) {
      files.forEach((file: any) => {
        this.reqPayload.append('files', file);
      });
    }
  }

  validate(file: File) {
    const _validFileExtensions = ['.doc', '.docx', '.pdf'];
    const fileNameExtension = file.name.substring(file.name.lastIndexOf('.'));
    const validateType = _validFileExtensions.indexOf(fileNameExtension);
    const maximunSize = 10 << 20;
    if (file.size > maximunSize) {
      this.toastrService.showNotification('snackbar-danger', `${file.name} has size greater than 10mb`);
      return false;
    }
    if (validateType === -1) {
      this.toastrService.showNotification('snackbar-danger', `${file.name} not allow. Error: Only pdf and doc files are allowed`);
      return false;
    }
    for (const f of this.selectedFiles) {
      if (f.name === file.name && f.lastModified === file.lastModified && f.size === f.size && f.type === f.type) {
        this.toastrService.showNotification('snackbar-danger', `${file.name} already selected`);
        return false;
      }
    }
    return true;
  }

  onFileSelected(event: any) {
    const _files = event.dataTransfer ? event.dataTransfer.files : event.target.files;
    for (let idx = 0; idx < _files.length; idx++) {
      const file = _files[idx];

      if (this.validate(file)) {
        file.objectURL = this.sanitizer.bypassSecurityTrustUrl(window.URL.createObjectURL(_files[idx]));

        // Select max files is 3
        if (this.maxLengthCert < 3) {
          this.selectedFiles.push(_files[idx]);
          this.maxLengthCert++;
          this.certFormGroup.controls['fileNames'].setValue(this.maxLengthCert);
        }
      }
    }
  }

  removeFile(event: any, file: any) {
    const indexOfFile = this.selectedFiles.indexOf(file);
    if (this.selectedFiles && -1 !== indexOfFile) {
      this.selectedFiles.splice(indexOfFile, 1);
      this.maxLengthCert--;
      this.certFormGroup.controls['fileNames'].setValue(this.maxLengthCert);
      this.fileUpload.nativeElement.value = '';
    }
  }
}
