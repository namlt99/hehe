import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InspectorCertFormDialogComponent } from './inspector-cert-form-dialog.component';

describe('InspectorCertFormDialogComponent', () => {
  let component: InspectorCertFormDialogComponent;
  let fixture: ComponentFixture<InspectorCertFormDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InspectorCertFormDialogComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(InspectorCertFormDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
