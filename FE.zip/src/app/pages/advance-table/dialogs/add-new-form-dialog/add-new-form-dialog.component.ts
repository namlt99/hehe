import { MAT_DIALOG_DATA, MatDialogRef, MatDialogContent, MatDialogClose } from '@angular/material/dialog';
import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { Validators, FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, AbstractControl, ValidatorFn } from '@angular/forms';
import { MAT_DATE_LOCALE, MatOptionModule } from '@angular/material/core';
import { AsyncPipe, CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatRadioModule } from '@angular/material/radio';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { _DetailProcess, _GBM, _Plant, _Process, _SelectSearchType, _Status } from '@core/models/common.model';
import { AddNewInspectorPayload, AddNewInspectorResponse, DialogDataModel, SearchUserPayloadModel } from '@core/models/Inspector.model';
import { SearchUserInputComponent } from '@shared/components/search-user-input/search-user-input.component';
import { IntraUserModel } from '@core/models/user.model';
import { InspectorService } from '@core/service/inspector.service';
import { AuthenticationService } from '@core/service/authentication.service';
import { AddNewForm } from '@core/models/inspector-form';
import { ToastrService } from '@core/service/toastr.service';
import { HTTP_RESPONSE_MESSAGE, LOCALE_CODE } from '@core/constant/helper.const';

export function ValidatorInput(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const value = control.value;
    if (value === 0 || value === '') {
      return { zeroOrEmpty: true };
    }
    return null;
  };
}

@Component({
  selector: 'app-form-dialog',
  templateUrl: './add-new-form-dialog.component.html',
  styleUrls: ['./add-new-form-dialog.component.scss'],
  providers: [{ provide: MAT_DATE_LOCALE, useValue: LOCALE_CODE.VN }],
  standalone: true,
  imports: [
    SearchUserInputComponent,
    MatButtonModule,
    MatIconModule,
    MatDialogContent,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatRadioModule,
    MatDatepickerModule,
    MatSelectModule,
    MatOptionModule,
    MatDialogClose,
    MatAutocompleteModule,
    AsyncPipe,
    CommonModule,
  ],
})
export class AddNewFormDialogComponent implements OnInit {
  @ViewChild('input') inputName: ElementRef<HTMLInputElement> | undefined;

  GBM = _GBM;
  Plant = _Plant;
  Process = _Process;
  DetailProcess = _DetailProcess;
  SelectSearchType = _SelectSearchType;
  Status = _Status;

  addNewFormGroup: FormGroup;
  addNewForm: AddNewForm = new AddNewForm();
  userForm: any;

  defaultPayload: SearchUserPayloadModel = {
    knox_id: null,
    pageSize: 10,
    pageNumber: 1,
  };

  // created_at = moment(new Date()).format('DD-MM-yyyy');

  constructor(
    public dialogRef: MatDialogRef<AddNewFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogDataModel,
    private formBuilder: FormBuilder,
    private inspectorService: InspectorService,
    private authenticationService: AuthenticationService,
    private toastrService: ToastrService
  ) {}

  ngOnInit() {
    this.addNewFormGroup = this.createAddNewForm();
  }

  createAddNewForm() {
    return this.formBuilder.group({
      employee_no: [this.addNewForm.employee_no, [Validators.required]],
      knox_id: [this.addNewForm.knox_id, [Validators.required]],
      employee_name: [this.addNewForm.employee_name, [Validators.required]],
      gbm: [{ value: this.addNewForm.gbm, disabled: true }],
      employee_team: [{ value: this.addNewForm.employee_team, disabled: true }],
      part: [{ value: this.addNewForm.part, disabled: true }],
      product: [{ value: this.addNewForm.product, disabled: true }],

      enter_date: [{ value: this.addNewForm.enter_date, disabled: true }],
      plant_id: [this.addNewForm.plant_id, [Validators.required, ValidatorInput()]],
      process_id: [this.addNewForm.process_id, [Validators.required, ValidatorInput()]],
      process_detail_id: [this.addNewForm.process_detail_id, [Validators.required, ValidatorInput()]],
      created_by: [this.authenticationService.currentUserValue.knox_id, [Validators.required]],
      remark: [this.addNewForm.remark, Validators.maxLength(1000)],
    });
  }

  selectedUser(user: IntraUserModel) {
    // Auto filled data after selected user
    if (!user) return;
    this.addNewFormGroup.controls['employee_no'].setValue(user.employee_no);
    this.addNewFormGroup.controls['knox_id'].setValue(user.knox_id);
    this.addNewFormGroup.controls['employee_name'].setValue(user.employee_name);
    this.addNewFormGroup.controls['gbm'].setValue(user.gbm);
    this.addNewFormGroup.controls['employee_team'].setValue(user.team);
    this.addNewFormGroup.controls['product'].setValue(user.product);
    this.addNewFormGroup.controls['part'].setValue(user.part);
    this.addNewFormGroup.controls['enter_date'].setValue(user.enter_date);
  }

  onClickCloseDialog(): void {
    this.dialogRef.close();
  }

  addNewUser(): void {
    if (this.addNewFormGroup.valid) {
      const remarkValue = this.addNewFormGroup.controls['remark'].value;

      const payload: AddNewInspectorPayload = {
        knox_id: this.addNewFormGroup.controls['knox_id'].value,
        employee_no: this.addNewFormGroup.controls['employee_no'].value,
        plant_id: this.addNewFormGroup.controls['plant_id'].value,
        process_detail_id: this.addNewFormGroup.controls['process_detail_id'].value,
        process_id: this.addNewFormGroup.controls['process_id'].value,
        created_by: this.authenticationService.currentUserValue.knox_id,
        remark: remarkValue ? remarkValue.trim() : null,
      };

      this.inspectorService.addNewInspector(payload).subscribe((res: AddNewInspectorResponse) => {
        if (res && res.message === HTTP_RESPONSE_MESSAGE.SUCCESS && res.newInspectorId) {
          this.inspectorService.isSuccess.next(true);
          this.toastrService.showNotification('snackbar-success', 'Add new success');
        }
      });
    }
  }
}
