import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { DeleteDialogComponent } from './dialogs/delete/delete.component';
import { MAT_DATE_LOCALE, MatRippleModule } from '@angular/material/core';
import { MatMenuModule } from '@angular/material/menu';
import { SelectionModel } from '@angular/cdk/collections';
import { UnsubscribeOnDestroyAdapter } from '../../shared/UnsubscribeOnDestroyAdapter';
import { NgClass, DatePipe, CommonModule, JsonPipe } from '@angular/common';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FeatherIconsComponent } from '../../shared/components/feather-icons/feather-icons.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { BreadcrumbComponent } from '../../shared/components/breadcrumb/breadcrumb.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { DeleteInspectorPayloadModel } from '@core/models/Inspector.model';
import { _DetailProcess, _GBM, _Plant, _Process, _SelectSearchType, _Status } from '@core/models/common.model';
import { SearchForm } from '@core/models/search-form';
import { AddNewFormDialogComponent } from './dialogs/add-new-form-dialog/add-new-form-dialog.component';
import { InspectorCertFormDialogComponent } from './dialogs/inspector-cert-form-dialog/inspector-cert-form-dialog.component';
import { InspectorService } from '@core/service/inspector.service';
import { AttachmentService } from '@core/service/attachment.service';
import { ExportExcelPayload } from '@core/models/attachment.model';
import { MatDatepickerModule } from '@angular/material/datepicker';
import moment from 'moment';
import { AuthenticationService } from '@core/service/authentication.service';
import { ToastrService } from '@core/service/toastr.service';
import { ACTION, HTTP_RESPONSE_MESSAGE, LOCALE_CODE } from '@core/constant/helper.const';
import { provideMomentDateAdapter } from '@angular/material-moment-adapter';

@Component({
  selector: 'app-advance-table',
  templateUrl: './advance-table.component.html',
  styleUrls: ['./advance-table.component.scss'],
  standalone: true,
  imports: [
    BreadcrumbComponent,
    MatTooltipModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatSortModule,
    NgClass,
    MatCheckboxModule,
    FeatherIconsComponent,
    MatRippleModule,
    MatProgressSpinnerModule,
    MatMenuModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    DatePipe,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatDatepickerModule,
    JsonPipe,
  ],
  providers: [{ provide: MAT_DATE_LOCALE,  useValue: LOCALE_CODE.VN }, provideMomentDateAdapter()],
})
export class AdvanceTableComponent extends UnsubscribeOnDestroyAdapter implements OnInit {
  displayedColumns = [
    'no',
    'knoxId',
    'fullName',
    'gbm',
    'part',
    'plant',
    'product',
    'enterDate',
    'process',
    'detailProcess',
    'remark',
    'lastCert',
    'passScore',
    'nextCert',
    'status',
    'delay',
  ];

  selection = new SelectionModel<any>(true, []);
  id?: number;

  searchFormGroup!: FormGroup;
  searchForm: SearchForm = new SearchForm();

  totalInspector: number | undefined;
  inspectorDataSource: MatTableDataSource<any> = new MatTableDataSource();

  GBM = _GBM;
  Plant = _Plant;
  Process = _Process;
  DetailProcess = _DetailProcess;
  SelectSearchType = _SelectSearchType;
  Status = _Status;

  // selectedFood = this.foods[2].value;

  defaultPayload = {}; // ==============================================

  pageIndex: number;
  pageSize: number = 10; // set pagesize
  step: number = 0;

  payloadDelete: DeleteInspectorPayloadModel = {
    ids: [],
    deleted_by: this.authenticationService.currentUserValue.knox_id, // getcurrentUser.knox_id
  };

  constructor(
    public httpClient: HttpClient,
    public dialog: MatDialog,
    private formBuilder: FormBuilder,
    private inspectorService: InspectorService,
    private attachmentService: AttachmentService,
    private toastrService: ToastrService,
    public authenticationService: AuthenticationService,
  ) {
    super();
    if (this.authenticationService.isAdmin) {
      this.displayedColumns.splice(1, 0, 'select');
    }
    this.GBM[0].value = '';

    this.createRangeForm();
  }

  @ViewChild(MatPaginator, { static: false }) paginator?: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

  range: FormGroup;
  maxDate = new Date();

  ngOnInit() {
    this.searchFormGroup = this.createSearchForm();

    // reload page when create or update is success
    this.inspectorService.$isSuccess.subscribe((res: any) => {
      if (res) {
        this.loadInspectorData();
      }
    });
  }

  ngAfterViewInit() {
    this.loadInspectorData();
  }

  onClickSearchForm() {
    this.loadInspectorData(false);
  }

  private formatValue(value: any) {
    return value !== '' && value !== 0 ? value : null;
  }

  private createPayloadSearch(pageSize: number, pageNumber: number) {
    const searchPayload: any = {
      pageSize: pageSize,
      pageNumber: pageNumber,
    };
    if (this.formatValue(this.searchFormGroup.value.searchStr)) {
      searchPayload.searchStr = this.searchFormGroup.value.searchStr;
    }
    if (this.formatValue(this.searchFormGroup.value.gbm)) {
      searchPayload.gbm = this.searchFormGroup.value.gbm;
    }
    if (this.formatValue(this.searchFormGroup.value.plant_id)) {
      searchPayload.plant_id = this.searchFormGroup.value.plant_id;
    }
    if (this.formatValue(this.searchFormGroup.value.process_id)) {
      searchPayload.process_id = this.searchFormGroup.value.process_id;
    }
    if (this.formatValue(this.searchFormGroup.value.process_detail_id)) {
      searchPayload.process_detail_id = this.searchFormGroup.value.process_detail_id;
    }
    if (this.formatValue(this.searchFormGroup.value.certificate_status_id)) {
      searchPayload.certificate_status_id = this.searchFormGroup.value.certificate_status_id;
    }
    return searchPayload;
  }

  loadInspectorData(isResetSearchForm: boolean = true, pageSize: number = this.pageSize, pageNumber: number = 1) {
    // if (!this.paginator) return;
    const searchPayload = this.createPayloadSearch(pageSize, pageNumber);

    this.inspectorService.getInspectorsList(searchPayload).subscribe((data: any) => {
      this.totalInspector = data.response.totalFound;
      this.step = (data.response.pageNumber - 1) * data.response.pageSize;
      const userData = data.response.data;
      this.inspectorDataSource = new MatTableDataSource(userData);

      this.inspectorDataSource.sort = this.sort;
      this.selection.clear();
      // reset search form value
      if (isResetSearchForm) {
        this.searchFormGroup.patchValue(this.searchForm);
      }

      // show notify for User when not found record
      if (this.inspectorDataSource.filteredData.length === 0) {
        this.toastrService.showNotification('snackbar-danger', 'Can not find any Inspector!');
      }
    });
    this.inspectorService.isSuccess.next(false);
  }

  handlePageEvent(event: PageEvent) {
    this.loadInspectorData(false, event.pageSize, event.pageIndex + 1);
  }

  createSearchForm() {
    return this.formBuilder.group({
      searchStr: [null],
      gbm: [this.searchForm.gbm],
      plant_id: [this.searchForm.plant_id],
      process_id: [this.searchForm.process_id],
      process_detail_id: [this.searchForm.process_detail_id],
      certificate_status_id: [this.searchForm.certificate_status_id],
    });
  }

  refresh() {
    this.loadInspectorData();
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.inspectorDataSource.filteredData.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ? this.selection.clear() : this.inspectorDataSource.filteredData.forEach((row) => this.selection.select(row));
  }

  selectedRows(row: any) {
    this.selection.toggle(row);
  }

  onClickAddNew() {
    if (!this.authenticationService.isAdmin) return;
    const dialogRef = this.dialog.open(AddNewFormDialogComponent, {
      width: '1200px',
      disableClose: true,
      data: {
        // advanceTable: this.advanceTable,
        action: ACTION.ADD,
      },
    });
    dialogRef.afterClosed().subscribe((res: any) => {
      if (res) {
        // this.loadInspectorData();
        // this.toastrService.showNotification('snackbar-success', 'Add new success');
      }
      this.selection.clear();
    });
  }

  onClickOpenInspectorCert() {
    if (!this.authenticationService.isAdmin) return;
    let dialogRef;
    if (this.selection.selected[0].hasOwnProperty('file_ids')) {
      dialogRef = this.dialog.open(InspectorCertFormDialogComponent, {
        width: '1200px',
        disableClose: true,
        data: {
          inspectorData: this.selection.selected,
          action: ACTION.UPDATE,
        },
      });
    } else {
      dialogRef = this.dialog.open(InspectorCertFormDialogComponent, {
        width: '1200px',
        disableClose: true,
        data: {
          inspectorData: this.selection.selected,
          action: ACTION.ADD,
        },
      });
    }
    dialogRef.afterClosed().subscribe((res: any) => {
      if (res) {
        // this.loadInspectorData();
        // this.toastrService.showNotification('snackbar-success', 'Update inspector success');
      }
      this.selection.clear();
    });
  }

  removeSelectedRows() {
    if (!this.authenticationService.isAdmin) return;
    const totalSelect = this.selection.selected.length;
    let textNotificaton = `${totalSelect} User Delete Successfully...!!!`;
    if (totalSelect > 1) {
      textNotificaton = `${totalSelect} Users Delete Successfully...!!!`;
    }

    const deleteDialogComponent = this.dialog.open(DeleteDialogComponent, {
      disableClose: true,
      data: this.selection.selected,
    });

    deleteDialogComponent.afterClosed().subscribe((result: any) => {
      // result === 1 mean close = true
      if (result === 1) {
        this.selection.selected.forEach((item) => {
          this.payloadDelete.ids.push(item.id);
        });
        this.inspectorService.deleteInspector(this.payloadDelete).subscribe((res: any) => {
          if (res.message === HTTP_RESPONSE_MESSAGE.SUCCESS) {
            this.payloadDelete.ids = [];
            this.loadInspectorData();
            this.toastrService.showNotification('snackbar-success', textNotificaton);
          }
        });

        this.selection.clear();
      }
    });
  }

  createRangeForm() {
    this.range = this.formBuilder.group({
      start: [null, [Validators.required]],
      end: [null, [Validators.required]],
    });
  }

  exportExcel() {
    if (!this.authenticationService.isAdmin) return;
    const payload: ExportExcelPayload = {
      from: this.range.controls['start'].value,
      to: this.range.controls['end'].value,
      name: `Inspector List ${moment(this.range.controls['start'].value).format('DD-MMMM-yyyy')} - ${moment(this.range.controls['end'].value).format(
        'DD-MMMM-yyyy'
      )}.xlsx`,
    };
    this.attachmentService.exportExcelByRangeDate(payload);
    this.range.reset();
  }
}
