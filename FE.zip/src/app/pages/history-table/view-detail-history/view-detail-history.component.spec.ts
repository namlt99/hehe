import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDetailHistoryComponent } from './view-detail-history.component';

describe('ViewDetailHistoryComponent', () => {
  let component: ViewDetailHistoryComponent;
  let fixture: ComponentFixture<ViewDetailHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewDetailHistoryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ViewDetailHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
