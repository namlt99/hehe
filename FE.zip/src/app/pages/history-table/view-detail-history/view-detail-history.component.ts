import { CommonModule, DatePipe, NgClass } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRippleModule } from '@angular/material/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { SafeHtmlPipe } from '@core/pipe/safe-html-pipe.pipe';
import { HistoryService } from '@core/service/history.service';
import { BreadcrumbComponent } from '@shared/components/breadcrumb/breadcrumb.component';
import { FeatherIconsComponent } from '@shared/components/feather-icons/feather-icons.component';

@Component({
  selector: 'app-view-detail-history',
  standalone: true,
  imports: [
    BreadcrumbComponent,
    MatTooltipModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatSortModule,
    NgClass,
    MatCheckboxModule,
    FeatherIconsComponent,
    MatRippleModule,
    MatProgressSpinnerModule,
    MatMenuModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    DatePipe,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    SafeHtmlPipe,
  ],
  templateUrl: './view-detail-history.component.html',
  styleUrl: './view-detail-history.component.scss',
})
export class ViewDetailHistoryComponent implements OnInit {
  insertDisplayedColumns = ['knox_id', 'employee_no', 'employee_name', 'created_by', 'created_at'];

  viewDetailHistoryDataSource: MatTableDataSource<any> = new MatTableDataSource();

  currentHistoryData: any;

  currentHistoryId: number;

  constructor(
    @Inject(MAT_DIALOG_DATA) public dialogDataModel: any,
    private historyService: HistoryService,
    public dialogRef: MatDialogRef<ViewDetailHistoryComponent>
  ) {}

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.currentHistoryId = this.dialogDataModel.historyData.id;

    this.historyService.getHistoryById(this.currentHistoryId).subscribe((data: any) => {
      this.currentHistoryData = data.result;
    });
  }

  onClickCloseDialog(): void {
    this.dialogRef.close();
  }
}
