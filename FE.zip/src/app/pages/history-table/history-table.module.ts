import { NgModule } from '@angular/core';
import { HistoryTableRoutingModule } from './history-table-routing.module';

@NgModule({
    imports: [HistoryTableRoutingModule,],
})
export class HistoryTableModule { }
