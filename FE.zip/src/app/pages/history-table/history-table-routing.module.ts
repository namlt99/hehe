import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HistoryTableComponent } from './history-table.component';

const routes: Routes = [
  {
    path: '',
    component: HistoryTableComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HistoryTableRoutingModule {}
