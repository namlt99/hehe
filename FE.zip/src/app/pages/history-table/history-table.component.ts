import { CommonModule, DatePipe, NgClass } from '@angular/common';
import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRippleModule } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { HistoryService } from '@core/service/history.service';
import { BreadcrumbComponent } from '@shared/components/breadcrumb/breadcrumb.component';
import { FeatherIconsComponent } from '@shared/components/feather-icons/feather-icons.component';
import { ViewDetailHistoryComponent } from './view-detail-history/view-detail-history.component';
import { ACTION, DATA_TABLE_NAME } from '@core/constant/helper.const';
import { SafeHtmlPipe } from '@core/pipe/safe-html-pipe.pipe';
import { _TableName } from '@core/models/common.model';
import { HistoryForm } from '@core/models/history';
import { Subscription, debounceTime } from 'rxjs';

@Component({
  selector: 'app-history-table',
  standalone: true,
  imports: [
    BreadcrumbComponent,
    MatTooltipModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatSortModule,
    NgClass,
    MatCheckboxModule,
    FeatherIconsComponent,
    MatRippleModule,
    MatProgressSpinnerModule,
    MatMenuModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    DatePipe,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    SafeHtmlPipe,
  ],
  templateUrl: './history-table.component.html',
  styleUrl: './history-table.component.scss',
})
export class HistoryTableComponent implements OnInit, OnDestroy {
  displayedColumns = ['no', 'table_name', 'action', 'log', 'timestamp', 'viewDetail'];

  historyDataSource: MatTableDataSource<any> = new MatTableDataSource();

  displayPageSize: number = 10;
  step: number = 0;

  totalHistory: number | undefined;
  totalFound: number | undefined;
  historyData: any;

  historyFormGroup!: FormGroup;
  historyForm: HistoryForm = new HistoryForm();

  TableName = _TableName;
  subs: Subscription[] = [];

  constructor(private historyService: HistoryService, public dialog: MatDialog, private formBuilder: FormBuilder) {
    this.TableName[0].value = '';
    this.TableName[1].value = 'inspectorinformation';
    this.historyFormGroup = this.createHistoryForm();
  }

  @ViewChild(MatPaginator, { static: false }) paginator?: MatPaginator;

  ngOnInit(): void {
    this.loadHistoryData();

    // reset data when search text box empty
    this.historyFormGroup.controls['knox_id'].valueChanges.pipe(debounceTime(500)).subscribe((res) => {
      if (!res) {
        this.loadHistoryData(false);
      }
    });
  }

  loadHistoryData(isResetSearchForm: boolean = true, pageSize: number = this.displayPageSize, pageNumber: number = 1): void {
    const defaultPayload = this.createPayloadSearch(pageSize, pageNumber);

    const searchValue = this.historyFormGroup.controls['knox_id'].value;
    if (searchValue) {
      defaultPayload.knox_id = searchValue;
    }
    this.subs.push(
      this.historyService.getAllHistory(defaultPayload).subscribe((data: any) => {
        this.totalHistory = data.response.total;
        this.totalFound = data.response.totalFound;
        this.step = (data.response.pageNumber - 1) * data.response.pageSize;
        const historyData = data.response.data;

        this.historyDataSource = new MatTableDataSource(this.formatData(historyData));

        if (isResetSearchForm) {
          this.historyFormGroup.patchValue(this.historyForm);
          defaultPayload.knox_id = null;
        }
      })
    );
  }

  private formatValue(value: any) {
    return value !== '' && value !== 0 ? value : null;
  }

  private createPayloadSearch(_pageSize: number, _pageNumber: number) {
    const payload: any = {
      pageSize: _pageSize,
      pageNumber: _pageNumber,
    };

    if (this.historyFormGroup && this.formatValue(this.historyFormGroup.value.table_name)) {
      payload.table_name = this.historyFormGroup.value.table_name;
    }
    if (this.historyFormGroup && this.formatValue(this.historyFormGroup.value.knox_id)) {
      payload.knox_id = this.historyFormGroup.value.knox_id;
    }

    return payload;
  }

  createHistoryForm() {
    return this.formBuilder.group({
      knox_id: [this.historyForm.knox_id],
      table_name: [this.historyForm.table_name],
    });
  }

  formatData(origin: any) {
    const result = origin.map((e: any) => {
      return {
        ...e,
        table_name: this.convertTableName(e.table_name),
      };
    });
    return result;
  }

  convertTableName(tableName: string) {
    if (tableName === DATA_TABLE_NAME.INSPECTOR_INFORMATION) return 'Inspector Information';
    return 'User';
  }

  handlePageEvent(event: PageEvent) {
    this.loadHistoryData(false, event.pageSize, event.pageIndex + 1);
  }

  onClickViewDetailHistory(currentHistory: any) {
    const dialogRef = this.dialog.open(ViewDetailHistoryComponent, {
      width: '1500px',
      disableClose: true,
      data: {
        historyData: currentHistory,
        action: ACTION.VIEW,
      },
    });
  }

  searchHistory() {
    this.loadHistoryData(false);
  }

  ngOnDestroy(): void {
    this.subs.forEach((sub) => {
      sub.unsubscribe();
    });
  }
}
