import { RouteInfo } from './sidebar.metadata';

export const ROUTES: RouteInfo[] = [
  {
    path: 'advance-table',
    title: 'Inspector List',
    icon: 'list',
    class: '',
    groupTitle: false,
    submenu: [],
  },
  {
    path: 'user-table',
    title: 'User List',
    icon: 'user',
    class: '',
    groupTitle: false,
    isAdmin: true,
    submenu: [],
  },
  {
    path: 'history-table',
    title: 'History',
    icon: 'trello',
    class: '',
    groupTitle: false,
    isAdmin: true,
    submenu: [],
  },
];
