import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DownloadCertPayload, ExportExcelPayload } from '@core/models/attachment.model';
import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AttachmentService {
  private readonly baseURL = `${environment.inspectorApi}/attachment`;

  constructor(private http: HttpClient) { }

  downloadCertificate(payload: DownloadCertPayload) {
    const url = `${this.baseURL}/downloadAttachment?fileNameUnique=${payload.file_name_unique}&id=${payload.id}`;
    this.downloadAttachment(url, payload.file_name_unique);
  }

  exportExcelByRangeDate(payload: ExportExcelPayload) {
    const url = `${this.baseURL}/exportExcel?from=${payload.from}&to=${payload.to}`;
    this.downloadAttachment(url, payload.name);
  }

  downloadAttachment(url: string, filename: string) {
    this.http.get(url, { responseType: 'blob' }).subscribe(
      (res: Blob) => {
        const blob = new Blob([res], { type: 'application/octet-stream' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      },
      (error) => {
        console.error('Download failed:', error);
      }
    );
  }
}
