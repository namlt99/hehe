import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root',
})
export class HistoryService {
  private readonly baseURL = `${environment.inspectorApi}/history`;

  constructor(private httpClient: HttpClient) { }

  getAllHistory(payload: any) {
    return this.httpClient.post(`${this.baseURL}/searchHistory`, payload);
  }

  getHistoryById(id: number) {
    return this.httpClient.post(`${this.baseURL}/getHistoryById`, { id });
  }
}
