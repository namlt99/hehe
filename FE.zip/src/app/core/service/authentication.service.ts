import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { LOCAL_STORAGE } from '@core/constant/helper.const';
import { IntraUserModel } from '@core/models/user.model';
import { environment } from 'environments/environment';
import { BehaviorSubject, Observable, map } from 'rxjs';
import { jwtDecode } from 'jwt-decode';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  private readonly baseURL = `${environment.inspectorApi}/authentication`;

  private currentUserSubject: BehaviorSubject<IntraUserModel>;
  public currentUser: Observable<IntraUserModel>;

  constructor(private http: HttpClient, private router: Router) {
    this.setCurrentUserSubject();
  }

  public get currentUserValue(): IntraUserModel {
    return this.currentUserSubject.value;
  }

  loginSSO(data: any): Observable<IntraUserModel> {
    return this.http.post<IntraUserModel>(`${this.baseURL}/loginsso`, { data }).pipe(
      map((response: any) => {
        localStorage.setItem(LOCAL_STORAGE.TOKEN, JSON.stringify(response.accessToken));

        const data = this.decodeAccessToken(response.accessToken);
        localStorage.setItem(LOCAL_STORAGE.CURRENT_USER, JSON.stringify(data.user));
        this.setCurrentUserSubject();
        return data.user;
      })
    );
  }

  private setCurrentUserSubject() {
    this.currentUserSubject = new BehaviorSubject<IntraUserModel>(JSON.parse(localStorage.getItem(LOCAL_STORAGE.CURRENT_USER) || '{}'));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public isAuthentication() {
    const token = localStorage.getItem(LOCAL_STORAGE.TOKEN) || null;
    if (token) {
      const decodedToken = this.decodeAccessToken(token);
      return new Date(decodedToken.exp) > new Date();
    }
    return false;
  }

  public get isAdmin(): boolean {
    // return this.currentUserValue.is_admin || this.isSuperAdmin ? true : false;
    return true;
  }

  public get isSuperAdmin(): boolean {
    return this.currentUserValue.knox_id.includes('tuoanh.ng') || this.currentUserValue.knox_id.includes('thanhnam.ly') || this.currentUserValue.knox_id.includes('hoanghao.ho') ? true : false;
  }

  logOut() {
    localStorage.removeItem(LOCAL_STORAGE.CURRENT_USER);
    localStorage.removeItem(LOCAL_STORAGE.TOKEN);
    this.router.navigate(['/authentication/signin']);
    this.currentUserSubject.next(JSON.parse('{}'));
  }

  decodeAccessToken(token: any): any {
    try {
      return jwtDecode(token);
    } catch (err) {
      return null;
    }
  }
}
