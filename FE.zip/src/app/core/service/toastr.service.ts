import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root',
})
export class ToastrService {

  constructor( private snackBar: MatSnackBar) {}

  showNotification(colorName: string, text: string, placementFrom: MatSnackBarVerticalPosition = 'bottom', placementAlign: MatSnackBarHorizontalPosition = 'center') {
    this.snackBar.open(text, '', {
      duration: 3000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }
}
