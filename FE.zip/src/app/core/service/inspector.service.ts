import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { AddNewInspectorPayload, AddNewInspectorResponse, DeleteInspectorPayloadModel, SearchUserPayloadModel } from '../../core/models/Inspector.model';
import { BehaviorSubject, Observable } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root',
})
export class InspectorService {
  private readonly baseURL = `${environment.inspectorApi}/inspector`;

  isSuccess = new BehaviorSubject<boolean>(false);
  $isSuccess = this.isSuccess.asObservable();

  constructor(private httpClient: HttpClient, private snackBar: MatSnackBar) { }

  addNewInspector(AddNewInspectorPayload: AddNewInspectorPayload): Observable<AddNewInspectorResponse> {
    return this.httpClient.post<AddNewInspectorResponse>(`${this.baseURL}/addNewInspector`, AddNewInspectorPayload);
  }

  getInspectorsList(payload: any) {
    return this.httpClient.post(`${this.baseURL}/searchInspectors`, payload);
  }

  deleteInspector(payload: DeleteInspectorPayloadModel) {
    return this.httpClient.post(`${this.baseURL}/inActiveMultiRows`, payload);
  }

  getInspectorById(id: number) {
    return this.httpClient.get(`${this.baseURL}/getInspectorById?id=${id}`);
  }

  registerCertificate(payload: any) {
    return this.httpClient.post(this.baseURL + '/registerCertificate', payload);
  }

  updateCertificate(payload: any) {
    return this.httpClient.post(this.baseURL + '/updateInspectorCertificate', payload);
  }
}
