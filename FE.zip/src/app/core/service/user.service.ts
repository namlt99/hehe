import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SearchAllUserPayloadModel } from '@core/models/Inspector.model';
import { SetAdminRolePayload, IntraUserModel, UserModel, InActivePayloadModel, SearchIntraUserPayloadModel } from '@core/models/user.model';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private readonly baseURL = `${environment.inspectorApi}/user`; //http://107.118.71.141:1999/user/searchUser
  constructor(private http: HttpClient) { }

  searchIntraUserByKnoxID(searchPayload: SearchIntraUserPayloadModel): Observable<IntraUserModel[]> {
    const url = `${this.baseURL}/searchIntraUser`;
    return this.http.post<IntraUserModel[]>(url, searchPayload);
  }

  searchUsers(payload: SearchAllUserPayloadModel): Observable<UserModel[]> {
    const url = `${this.baseURL}/searchUser`;
    // payload.sort ={column: 'is_admin',type:'asc'}
    return this.http.post<UserModel[]>(url, payload);
  }

  setAdminRole(payload: SetAdminRolePayload) {
    const url = `${this.baseURL}/setAdminRoleMultiRows`;
    return this.http.post(url, payload);
  }

  inActiveMultiUsers(payload: InActivePayloadModel) {
    const url = `${this.baseURL}/inActiveMultiUsers`;
    return this.http.post(url, payload);
  }
}
