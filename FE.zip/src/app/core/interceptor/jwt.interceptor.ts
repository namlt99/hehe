import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LOCAL_STORAGE } from '@core/constant/helper.const';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  constructor() {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const accessToken = localStorage.getItem(LOCAL_STORAGE.TOKEN);
    if (!accessToken) {
      return next.handle(request);
    }
    request = request.clone({
      setHeaders: {
        authorization: `Bearer ${accessToken}`,
        'Access-Control-Allow-Origin': '*',
      },
      withCredentials: true,
    });
    return next.handle(request);
  }
}
