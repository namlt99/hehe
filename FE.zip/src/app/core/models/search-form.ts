export class SearchForm {
  pageSize: number;
  pageNumber: number;
  searchStr: string;
  gbm?: string;
  plant_id?: number;
  process_id?: number;
  process_detail_id?: number;
  certificate_status_id?: number;

  constructor() {
    this.pageSize = 0;
    this.pageNumber = 0;
    this.searchStr = "";
    this.gbm = "";
    this.plant_id = 0;
    this.process_id = 0;
    this.process_detail_id = 0;
    this.certificate_status_id = 0;
  }
}
