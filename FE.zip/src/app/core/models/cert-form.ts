export class CertForm {
  id: number;
  employee_name: string;
  employee_team: string;
  created_at: string;
  gbm: string;
  plant_name?: string;
  product: string;
  process_name: string;
  process_detail_name: string;
  part: string;
  enter_date:string;
  remark?: string;
  start_date: string | null;
  end_date: string | null;
  pass_score: number | null;
  last_certificate_date: string | null;
  next_certificate_date: string | null;
  created_by: string;
  file_names: string;
  registrant_knox_id: number | null;
  registrant_name: string | null;
  registrant_no: number | null;
  files: File[];
  file_ids: string[];
  file_name_uniques: string[];

  constructor(

  ) {
    this.id = 0
    this.employee_name = '';
    this.employee_team = '';
    this.product = '';
    this.gbm = '';
    this.process_name = '';
    this.process_detail_name = '';
    this.remark = '';
    this.created_at = '';
    this.created_by = '';
    this.part = '';
    this.start_date = null;
    this.enter_date= '',
    this.end_date = null;
    this.pass_score = null;
    this.last_certificate_date = null;
    this.next_certificate_date = null;
    this.file_names = '';
    this.registrant_knox_id = null;
    this.registrant_name = null;
    this.registrant_no = null;
    this.files = []
    this.file_ids = [];
    this.file_name_uniques = [];
  }
}
