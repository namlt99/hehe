export class AddNewForm {
  employee_no: string | null;
  knox_id: string | null;
  employee_name: string | null;
  employee_team: string | null;
  product: string | null;
  gbm: string | null;
  plant_id: number | null;
  plant_name?: string;
  process_id: number;
  process_name: string;
  process_detail_id: number;
  process_detail_name: string;
  certificate_status_id: number;
  remark?: string | null;
  is_actived: number;
  // created_at: string;
  enter_date:string|null;
  created_by: string | null;
  part: string | null;
  start_date: string | null;
  end_date: string | null;
  pass_score: number | null;
  last_certificate_date: string | null;
  next_certificate_date: string | null;
  id: number;
  file_ids: string[];
  file_name_uniques: string[];
  file_names: string[];

  constructor() {
    this.employee_no = null;
    this.knox_id = null;
    this.employee_name = null;
    this.employee_team = null;
    this.product = null;
    this.gbm = null;
    this.plant_id = 0;
    this.process_id = 0;
    this.process_name = '';
    this.process_detail_id = 0;
    this.process_detail_name = '';
    this.certificate_status_id = 0;
    this.remark = null;
    this.is_actived = 0;
    // this.created_at = '';
    this.enter_date= null;
    this.created_by = null;
    this.part = null;
    this.start_date = null;
    this.end_date = null;
    this.pass_score = null;
    this.last_certificate_date = null;
    this.next_certificate_date = null;
    this.id = 0;
  }
}
