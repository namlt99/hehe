import { DetailProcess, GBM, Plant, Process, SelectSearchType, Status, TableName } from '@core/enum/search-model';

export const _GBM = Object.keys(GBM)
.filter((v) => isNaN(Number(v)))
.map((key, index) => {
  return { value: key, viewValue: key };
});

export const _Plant = Object.keys(Plant)
.filter((v) => isNaN(Number(v)))
.map((key, index) => {
  return { value: index, viewValue: key };
});

export const _Process = Object.keys(Process)
.filter((v) => isNaN(Number(v)))
.map((key, index) => {
  return { value: index, viewValue: key };
});

export const _DetailProcess = Object.keys(DetailProcess)
.filter((v) => isNaN(Number(v)))
.map((key, index) => {
  return { value: index, viewValue: key };
});

export const _SelectSearchType = Object.keys(SelectSearchType)
.filter((v) => isNaN(Number(v)))
.map((key, index) => {
  return { value: index, viewValue: key };
});

export const _Status = Object.keys(Status)
.filter((v) => isNaN(Number(v)))
.map((key, index) => {
  return { value: index, viewValue: key };
});

export const _TableName = Object.keys(TableName)
.filter((v) => isNaN(Number(v)))
.map((key, index) => {
  return { value: key, viewValue: key };
});
