export interface DownloadCertPayload{
  file_name_unique: string;
  id: string;
}

export interface TotalUserCert {
  file_ids: string[];
  file_name_uniques: string[];
  file_names: string[];
}

export interface ExportExcelPayload {
  from: Date;
  to: Date;
  name: string;
}
