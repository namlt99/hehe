export class HistoryForm {
  table_name?: string;
  knox_id?: string;

  constructor() {
    this.table_name = '';
    this.knox_id = '';
  }
}
