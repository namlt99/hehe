import { AddNewForm } from './inspector-form';

export interface DeleteInspectorPayloadModel {
  ids: number[];
  deleted_by: string; // EP_LOGINID
}

export interface SearchUserPayloadModel {
  knox_id: string | null;
  pageSize: number;
  pageNumber: number;
}

export interface SearchIntraUserPayloadModel {
  searchStr: string | null;
  pageSize: number;
  pageNumber: number;
}

export interface SearchAllUserPayloadModel {
  searchStr: string | null;
  pageSize: number;
  pageNumber: number;
  sort: Sort | null;
}

export interface Sort {
  column: string;
  type: string;
}
export interface SearchUserResponseModel {
  data: [];
  pageNumber: number;
  pageSize: number;
  totalFound: number;
}

export interface DialogDataModel {
  id: number;
  action: string;
  inspectorData: AddNewForm[];
}

export interface AddNewInspectorPayload {
  employee_no: string;
  knox_id: string;
  plant_id: number;
  process_id: number;
  process_detail_id: number;
  remark?: string;
  created_by: string;
}

export interface AddNewInspectorResponse {
  message: string;
  newInspectorId: number;
}

export interface RegisterCertificate {
  id: number;
  pass_score: number;
  start_date: string;
  end_date: string;
  last_certificate_date: string;
  next_certificate_date: string;
  files: File[];
  registrant_no: string;
  registrant_knox_id: string;
  registrant_name: string;
}
