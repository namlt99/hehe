export interface SearchIntraUserPayloadModel {
  pageSize: number;
  pageNumber: number;
  searchStr: string;
}

export interface IntraUserModel {
  knox_id: string;
  employee_no: string;
  employee_name: string;
  employee_name_en: string;
  employee_email: string;
  gender: string;
  phone: string;
  team: string | null;
  group: string | null;
  part: string | null;
  gbm: string;
  enter_date: string;
  product: string | null;
  cost_center: string | null;
  cost_center_name: string | null;
  status: boolean;
  current: string;
  is_admin?: boolean;
  is_active?: boolean;
}

export interface UserModel {
  knox_id: string;
  employee_no: string;
  employee_name: string;
  employee_email: string;

  is_admin?: boolean;
  status?: boolean;
  current?: string;
  created_by: string;
  created_at: string;
  modified_by: string;
  modified_at: string;
}

export interface SetAdminRolePayload {
  ids: number[];
  knox_ids: string[];
  modified_by: string;
}


export interface InActivePayloadModel {
  ids: number[];
  knox_ids: string[];
  modified_by: string;
}
