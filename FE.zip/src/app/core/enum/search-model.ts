export enum GBM {
  'All',
  'DA',
  'VD',
}

export enum Plant {
  'All',
  '[P552]SEHC',
  '[P553]SEHC',
  '[P554]SEHC',
}

export enum Process {
  'All',
  'CS',
  'Manufacturing'
}

export enum DetailProcess {
  'All',
  'IQC',
  'OQC/Mass',
  'IBI',
  'QA(Aging, Reliability)',
  'CNC QC',
  'Device QC',
  'RMA Repair',
  'ETC'
}

export enum SelectSearchType {
  'All',
  'Gen ID',
  'Knox ID'
}

export enum Status {
  'All',
  'Certification Plan',
  'Certification Complete',
  'Certification No Need',
  'Certification Delay'
}

export enum TableName {
  'All',
  'Inspector Information',
  'User'
}
