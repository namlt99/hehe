import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from '@core/service/authentication.service';


@Injectable({
  providedIn: 'root',
})
export class AuthGuard  {
  constructor(private router: Router, private authenticationService: AuthenticationService) {}
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot,) {
    // if (!this.authenticationService.isAuthentication()) {
    //   this.authenticationService.logOut()
    //   return false;
    // }
    
    return true;
  }
}
