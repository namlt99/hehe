export * from './core.module';

// services
export { RightSidebarService } from './service/rightsidebar.service';

// models

export { User } from './models/user';
export { InConfiguration } from './models/config.interface';
