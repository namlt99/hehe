export const ACTION = {
  ADD: 'add',
  UPDATE: 'update',
  VIEW: 'view'
}
export const LOCALE_CODE = {
  VN: 'vi-VN',
  FRENCH: 'fr-FR'
}

export const HTTP_RESPONSE_MESSAGE = {
  SUCCESS: 'success',
  ERROR: 'error',
}

export const LOCAL_STORAGE = {
  CURRENT_USER: "current_user",
  TOKEN: 'token'
}

export const DATA_TABLE_NAME = {
  INSPECTOR_INFORMATION: "inspectorinformation",
  USER: "user",
};
