import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AbstractControl, UntypedFormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { NgClass } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { AuthenticationService } from '@core/service/authentication.service';
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss'],
  standalone: true,
  imports: [RouterLink, FormsModule, ReactiveFormsModule, MatIconModule, MatFormFieldModule, NgClass, MatButtonModule],
})
export class SigninComponent implements OnInit {
  loginForm!: UntypedFormGroup;
  submitted = false;
  error = '';
  hide = true;

  constructor(private router: Router, private authenticationService: AuthenticationService) {}
  ngOnInit() {}

  get form(): { [key: string]: AbstractControl } {
    return this.loginForm.controls;
  }

  login() {
    const webSocket = new WebSocket('ws://127.0.0.1:29282');
    webSocket.onopen = function (e: any) {
      webSocket.send('{"rqtype":"getknoxsso","token":"","data":"KCC10TRAY0003"}');
    };
    webSocket.onerror = function (err: any) {
      console.log('error socket', err);
    };
    webSocket.onmessage = (e: any) => {
      const data = e.data;
      if (e.data) {
        this.authenticationService.loginSSO(data).subscribe((res) => {
          if(res){
            this.router.navigate(['/advance-table']);
          }
        });
      }
    };
  }
}
