import { NgModule } from '@angular/core';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { SharedModule } from '../shared.module';
import { MaterialFileUploadComponent } from './material-file-upload/material-file-upload.component';
import { SearchUserInputComponent } from './search-user-input/search-user-input.component';

@NgModule({
  imports: [SharedModule, FileUploadComponent, BreadcrumbComponent, MaterialFileUploadComponent, SearchUserInputComponent],
  exports: [FileUploadComponent, BreadcrumbComponent, MaterialFileUploadComponent, SearchUserInputComponent],
})
export class ComponentsModule {}
