import { CommonModule } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator } from '@angular/material/paginator';
import { SearchIntraUserPayloadModel, IntraUserModel } from '@core/models/user.model';
import { UserService } from '@core/service/user.service';
import { debounceTime, distinctUntilChanged, of, startWith, switchMap } from 'rxjs';

@Component({
  selector: 'app-search-user-input',
  standalone: true,
  imports: [MatInputModule, MatOptionModule, MatAutocompleteModule, ReactiveFormsModule, MatPaginator, MatFormFieldModule, CommonModule],
  templateUrl: './search-user-input.component.html',
  styleUrl: './search-user-input.component.scss',
})
export class SearchUserInputComponent implements OnInit {
  @Output() selectedUser = new EventEmitter<IntraUserModel>();

  myControl = new FormControl('', [Validators.required]);
  filteredOptions: IntraUserModel[];

  searchPayload: SearchIntraUserPayloadModel = {
    pageNumber: 1,
    pageSize: 30,
    searchStr: '',
  };

  totalFound: number = 0;

  constructor(private userService: UserService) {}

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.myControl.valueChanges
      .pipe(
        startWith(''),
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((res: any) => {
          if (res) {
            this.searchPayload.searchStr = res;
            return this.userService.searchIntraUserByKnoxID(this.searchPayload);
          }
          return of(undefined);
        })
      )
      .subscribe((res: any) => {
        if (res && res.response.data && res.response.data.length) {
          this.totalFound = res.response.totalFound;
          this.filteredOptions = res.response.data;
        } else {
          this.filteredOptions = [];
        }
      });
  }

  onSelect(selecteduser: IntraUserModel) {
    if (selecteduser) {
      this.selectedUser.emit(selecteduser);
    }
  }
}
