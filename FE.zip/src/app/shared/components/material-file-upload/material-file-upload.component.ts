import { AsyncPipe, CommonModule } from '@angular/common';
import { HttpClient, HttpErrorResponse, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogClose, MatDialogContent } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { DomSanitizer } from '@angular/platform-browser';
import { Subscription, catchError, last, map, of, tap } from 'rxjs';

@Component({
  selector: 'app-material-file-upload',
  standalone: true,
  templateUrl: './material-file-upload.component.html',
  styleUrl: './material-file-upload.component.scss',
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatDialogContent,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatRadioModule,
    MatDatepickerModule,
    MatSelectModule,
    MatOptionModule,
    MatDialogClose,
    MatAutocompleteModule,
    AsyncPipe,
    MaterialFileUploadComponent,
  ],
})
export class MaterialFileUploadComponent implements OnInit {
  @Input()
  mode: any;
  @Input()
  names: any;
  @Input()
  url : any;
  @Input()
  method: any;
  @Input()
  multiple: any;
  @Input()
  disabled: any;
  @Input()
  accept: any;
  @Input()
  maxFileSize: any;
  @Input()
  auto = true;
  @Input()
  withCredentials: any;
  @Input()
  invalidFileSizeMessageSummary: any;
  @Input()
  invalidFileSizeMessageDetail: any;
  @Input()
  invalidFileTypeMessageSummary: any;
  @Input()
  invalidFileTypeMessageDetail: any;
  @Input()
  previewWidth: any;
  @Input()
  chooseLabel = 'Choose';
  @Input()
  uploadLabel = 'Upload';
  @Input()
  cancelLabel = 'Cance';
  @Input()
  customUpload: any;
  @Input()
  showUploadButton: any;
  @Input()
  showCancelButton: any;

  @Input()
  dataUriPrefix: any;
  @Input()
  deleteButtonLabel: any;
  @Input()
  deleteButtonIcon = 'close';
  @Input()
  showUploadInfo: any;

  /**
   *
   */

  @ViewChild('fileUpload')
  fileUpload!: ElementRef;

  inputFileName: string | undefined;

  @Input()
  files: File[] = [];

  constructor(private sanitizer: DomSanitizer) {}
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  onClick(event: any) {
    if (this.fileUpload) this.fileUpload.nativeElement.click();
  }

  onInput(event: any) {}

  onFileSelected(event: any) {
    let files = event.dataTransfer ? event.dataTransfer.files : event.target.files;
    console.log('event::::::', event);
    for (let i = 0; i < files.length; i++) {
      let file = files[i];

      //if(!this.isFileSelected(file)){
      if (this.validate(file)) {
        //      if(this.isImage(file)) {
        file.objectURL = this.sanitizer.bypassSecurityTrustUrl(window.URL.createObjectURL(files[i]));
        //      }
        if (!this.isMultiple()) {
          this.files = [];
        }
        this.files.push(files[i]);
        //  }
      }
      //}
    }
  }

  removeFile(event: any, file: any) {
    let ix;
    if (this.files && -1 !== (ix = this.files.indexOf(file))) {
      this.files.splice(ix, 1);
      this.clearInputElement();
    }
  }

  validate(file: File) {
    for (const f of this.files) {
      if (f.name === file.name && f.lastModified === file.lastModified && f.size === f.size && f.type === f.type) {
        return false;
      }
    }
    return true;
  }

  clearInputElement() {
    this.fileUpload.nativeElement.value = '';
  }

  isMultiple(): boolean {
    return this.multiple;
  }
}
