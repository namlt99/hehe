export const environment = {
  production: true,
  apiUrl: 'http://localhost:4200',
  // inspectorApi: 'http://107.118.99.54/api-im',
  inspectorApi: 'http://localhost:1999'
};
