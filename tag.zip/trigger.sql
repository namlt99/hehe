use inspectormanagement;
DELIMITER $$

CREATE TRIGGER insert_inspector_trigger AFTER INSERT ON inspectormanagement.inspectorinformation
	FOR EACH ROW
		INSERT INTO history (action, table_name, old_data, new_data)
		VALUES ('insert', 'inspectorinformation', NULL, JSON_OBJECT('knox_id', NEW.knox_id, 'employee_no', NEW.employee_no, 'employee_name', NEW.employee_name,'created_at', NEW.created_at,'created_by', NEW.created_by));

CREATE TRIGGER update_inspector_trigger AFTER UPDATE ON inspectormanagement.inspectorinformation
	FOR EACH ROW
		INSERT INTO history (action, table_name, old_data, new_data)
		VALUES ('update', 'inspectorinformation', JSON_OBJECT('knox_id', OLD.knox_id, 'employee_no', OLD.employee_no, 'employee_name', OLD.employee_name,'start_date',OLD.start_date,'end_date',OLD.end_date,'last_certificate_date',OLD.last_certificate_date,'next_certificate_date',OLD.next_certificate_date,'pass_score',OLD.pass_score,'registrant_knox_id',OLD.registrant_knox_id,'modified_by',OLD.modified_by,'modified_at',OLD.modified_at,'created_by', OLD.created_by), JSON_OBJECT('knox_id', NEW.knox_id, 'employee_no', NEW.employee_no, 'employee_name', NEW.employee_name,'start_date',NEW.start_date,'end_date',NEW.end_date,'last_certificate_date',NEW.last_certificate_date,'next_certificate_date',NEW.next_certificate_date,'pass_score',NEW.pass_score,'is_active',NEW.is_active,'registrant_knox_id',NEW.registrant_knox_id,'modified_by',NEW.modified_by,'modified_at',NEW.modified_at));

CREATE TRIGGER insert_user_trigger AFTER INSERT ON inspectormanagement.user
	FOR EACH ROW
		INSERT INTO history (action, table_name, old_data, new_data)
		VALUES ('insert', 'user', NULL, JSON_OBJECT('knox_id', NEW.knox_id, 'employee_no', NEW.employee_no, 'employee_name', NEW.employee_name,'created_at', NEW.created_at,'created_by', NEW.created_by));

CREATE TRIGGER update_user_trigger AFTER UPDATE ON inspectormanagement.user
	FOR EACH ROW
		INSERT INTO history (action, table_name, old_data, new_data)
		VALUES ('update', 'user', JSON_OBJECT('knox_id', NEW.knox_id, 'employee_no', NEW.employee_no, 'employee_name', NEW.employee_name,'created_at', NEW.created_at,'created_by', NEW.created_by), JSON_OBJECT('knox_id', NEW.knox_id, 'employee_no', NEW.employee_no, 'employee_name', NEW.employee_name,'is_admin',NEW.is_admin,'is_active',NEW.is_active,'modified_by',NEW.modified_by,'modified_at',NEW.modified_at,'set_role_by',NEW.set_role_by,'set_role_at',NEW.set_role_at));



DELIMITER ;
